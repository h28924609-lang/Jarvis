package br.jarvis.plugin.core

import org.json.JSONObject

/** Canal único de eventos Kotlin -> Godot. Eventos ficam em buffer enquanto a interface não está anexada. */
object JarvisBus {
    fun interface Listener { fun onEvent(name: String, payloadJson: String) }

    private val lock = Any()
    private var listener: Listener? = null
    private val pending = ArrayDeque<Pair<String, String>>()

    fun emit(name: String, payload: JSONObject = JSONObject()) {
        val json = payload.toString()
        synchronized(lock) {
            val l = listener
            if (l == null) {
                if (name != "audio_level") {
                    if (pending.size >= 200) pending.removeFirst()
                    pending.addLast(name to json)
                }
            } else {
                l.onEvent(name, json)
            }
        }
    }

    fun attach(l: Listener) {
        synchronized(lock) {
            listener = l
            while (pending.isNotEmpty()) {
                val (n, j) = pending.removeFirst()
                l.onEvent(n, j)
            }
        }
    }

    fun detach() { synchronized(lock) { listener = null } }
}
