package br.jarvis.plugin.voice

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.jo
import br.jarvis.plugin.security.SecurityGuard

/**
 * Reconhecimento de voz pt-BR com SpeechRecognizer (preferindo modo offline).
 * Modo WAKE: escuta contínua em sessões curtas procurando "Jarvis". Modo COMMAND: captura um comando.
 * Observação honesta: não é um detector de palavra-chave dedicado; consome mais bateria que um
 * (ver documentation/ARQUITETURA.md para alternativas como Porcupine/Vosk).
 */
class VoiceEngine(
    private val ctx: Context,
    private val onCommand: (String) -> Unit,
    private val onIdle: () -> Unit
) {
    enum class Mode { OFF, WAKE, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    @Volatile var mode = Mode.OFF
        private set
    private var failures = 0
    private var lastRms = 0L

    private val wakeRegex = Regex("\\b(jarvis|jarvi|jarvas|garvis|jarves|djarvis|charvis)\\b")

    fun start(m: Mode) = main.post { mode = m; failures = 0; begin() }
    fun stop() = main.post { mode = Mode.OFF; destroy() }

    private fun intent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
    }

    private fun begin() {
        if (mode == Mode.OFF) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            JarvisBus.emit("message", jo("role" to "assistant", "text" to "Reconhecimento de voz indisponível neste aparelho."))
            mode = Mode.OFF; onIdle(); return
        }
        destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).also {
            it.setRecognitionListener(listener)
            it.startListening(intent())
        }
        JarvisBus.emit("state", jo("state" to "listening"))
    }

    private fun destroy() { rec?.cancel(); rec?.destroy(); rec = null }

    private fun restart(delayMs: Long) { main.postDelayed({ if (mode != Mode.OFF) begin() }, delayMs) }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            val now = System.currentTimeMillis()
            if (now - lastRms < 70) return
            lastRms = now
            JarvisBus.emit("audio_level", jo("level" to ((rmsdB + 2f) / 12f).coerceIn(0f, 1f).toDouble()))
        }

        override fun onResults(results: android.os.Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            failures = 0
            when (mode) {
                Mode.WAKE -> handleWake(list)
                Mode.COMMAND -> {
                    mode = Mode.OFF; destroy()
                    val text = list.firstOrNull().orEmpty().trim()
                    if (text.isEmpty()) onIdle() else onCommand(text)
                }
                Mode.OFF -> {}
            }
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    if (mode == Mode.WAKE) restart(250)
                    else { mode = Mode.OFF; destroy(); JarvisBus.emit("message", jo("role" to "assistant", "text" to "Não ouvi nada. Toque no microfone para tentar de novo.")); onIdle() }
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> restart(1000)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    mode = Mode.OFF; destroy()
                    JarvisBus.emit("message", jo("role" to "assistant", "text" to "Sem permissão de microfone."))
                    onIdle()
                }
                else -> {
                    failures++
                    if (failures > 6) {
                        mode = Mode.OFF; destroy()
                        JarvisBus.emit("message", jo("role" to "assistant", "text" to "A escuta parou após falhas repetidas do reconhecedor de voz."))
                        onIdle()
                    } else restart(1500L * failures)
                }
            }
        }
    }

    private fun handleWake(results: List<String>) {
        for (r in results) {
            val n = SecurityGuard.norm(r)
            val m = wakeRegex.find(n) ?: continue
            val rest = n.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
            destroy()
            if (rest.length >= 3) { mode = Mode.OFF; onCommand(rest) }
            else { mode = Mode.COMMAND; JarvisBus.emit("message", jo("role" to "system", "text" to "Estou ouvindo…")); begin() }
            return
        }
        restart(200)
    }
}
