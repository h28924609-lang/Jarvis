package br.jarvis.plugin

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.JarvisConfig
import br.jarvis.plugin.core.JarvisCore
import br.jarvis.plugin.core.jo
import br.jarvis.plugin.security.ConfirmationGate
import br.jarvis.plugin.voice.VoiceService
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import org.json.JSONObject

/**
 * Ponte Godot <-> Android. Métodos recebem/retornam apenas String/Boolean (JSON quando preciso).
 * Eventos chegam ao Godot por um único sinal: jarvis_event(nome: String, payload_json: String).
 */
class JarvisPlugin(godot: Godot) : GodotPlugin(godot), JarvisBus.Listener {

    private val eventSignal = SignalInfo("jarvis_event", String::class.java, String::class.java)

    override fun getPluginName(): String = "JarvisPlugin"
    override fun getPluginSignals(): MutableSet<SignalInfo> = mutableSetOf(eventSignal)

    // Se a versão da godot-lib usada tiver outra assinatura de emitSignal, ajuste somente esta linha.
    override fun onEvent(name: String, payloadJson: String) {
        emitSignal(godot, pluginName, eventSignal, name, payloadJson)
    }

    private val ctx get() = activity!!.applicationContext

    private fun permissionStatus(): JSONObject {
        val pm = ctx.getSystemService(PowerManager::class.java)
        return jo(
            "accessibility" to JarvisCore.accessibilityEnabled(),
            "microphone" to VoiceService.hasMic(ctx),
            "notifications" to (Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED),
            "battery" to pm.isIgnoringBatteryOptimizations(ctx.packageName),
            "ai_configured" to JarvisConfig.isAiConfigured
        )
    }

    private fun config(): JSONObject = jo(
        "server_url" to JarvisConfig.serverUrl,
        "has_token" to JarvisConfig.token.isNotBlank(),
        "speak" to JarvisConfig.speakReplies,
        "wake" to JarvisConfig.wakeEnabled,
        "extra_blocked" to org.json.JSONArray(JarvisConfig.extraBlocked.toList())
    )

    // ---------- ciclo de vida ----------
    @UsedByGodot
    fun jarvisInit(): String {
        JarvisCore.init(ctx)
        return jo("permissions" to permissionStatus(), "config" to config()).toString()
    }

    /** Chamado pela UI depois de conectar os sinais; descarrega eventos em buffer. */
    @UsedByGodot
    fun jarvisAttach() { JarvisBus.attach(this) }

    override fun onMainResume() { JarvisBus.emit("permissions_changed", permissionStatus()) }
    override fun onMainDestroy() { JarvisBus.detach() }

    override fun onMainRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        JarvisBus.emit("permissions_changed", permissionStatus())
    }

    // ---------- permissões (sempre por ação explícita do usuário) ----------
    @UsedByGodot fun getPermissionStatus(): String = permissionStatus().toString()

    @UsedByGodot fun openAccessibilitySettings() {
        activity?.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    @UsedByGodot fun openAppDetails() {
        activity?.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }

    @UsedByGodot fun openBatterySettings() {
        activity?.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    @UsedByGodot fun requestMicPermission() {
        activity?.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7001)
    }

    @UsedByGodot fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) activity?.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7002)
    }

    // ---------- configuração ----------
    @UsedByGodot fun getConfig(): String = config().toString()

    @UsedByGodot fun setServer(url: String, token: String) {
        JarvisConfig.serverUrl = url
        if (token.isNotBlank()) JarvisConfig.token = token
        JarvisBus.emit("permissions_changed", permissionStatus())
    }

    @UsedByGodot fun setSpeakReplies(on: Boolean) { JarvisConfig.speakReplies = on }

    /** Apenas ACRESCENTA bloqueios; a lista padrão de bancos não pode ser reduzida. */
    @UsedByGodot fun addBlockedPackage(pkg: String) {
        val set = JarvisConfig.extraBlocked.toMutableSet().apply { add(pkg.trim().lowercase()) }
        JarvisConfig.extraBlocked = set
        br.jarvis.plugin.security.SecurityGuard.addExtraBlocked(listOf(pkg))
    }

    @UsedByGodot fun testConnection() { JarvisCore.testConnection() }

    // ---------- voz ----------
    @UsedByGodot fun startWakeListening() { VoiceService.startWake(ctx) }
    @UsedByGodot fun stopWakeListening() { VoiceService.stop(ctx) }
    @UsedByGodot fun listenOnce() { VoiceService.listenOnce(ctx) }

    // ---------- comandos e tarefas ----------
    @UsedByGodot fun sendCommand(text: String) { JarvisCore.submitCommand(text, "text") }
    @UsedByGodot fun cancelTask() { JarvisCore.cancelTask() }
    @UsedByGodot fun confirmAction(id: String, approved: Boolean) { ConfirmationGate.resolve(id, approved) }
}
