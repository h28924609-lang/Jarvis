package br.jarvis.plugin.core

import org.json.JSONArray
import org.json.JSONObject

fun jo(vararg p: Pair<String, Any?>): JSONObject {
    val o = JSONObject()
    for ((k, v) in p) o.put(k, v ?: JSONObject.NULL)
    return o
}

fun ja(items: Iterable<Any?>): JSONArray {
    val a = JSONArray()
    items.forEach { a.put(it) }
    return a
}
