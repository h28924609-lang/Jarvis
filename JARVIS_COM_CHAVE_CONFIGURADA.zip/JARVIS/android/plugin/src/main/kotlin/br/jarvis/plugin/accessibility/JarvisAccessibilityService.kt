package br.jarvis.plugin.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.JarvisCore
import br.jarvis.plugin.core.jo
import br.jarvis.plugin.security.SecurityGuard
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/**
 * Serviço de acessibilidade: único ponto de leitura e toque na interface do Android.
 * Eventos apenas incrementam um contador (barato); a árvore só é lida sob demanda.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        val screenVersion = AtomicLong(0)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        JarvisCore.init(applicationContext)
        JarvisBus.emit("permissions_changed", jo("accessibility" to true))
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                screenVersion.incrementAndGet()
                // Defesa em profundidade: se um app bancário aparecer durante uma tarefa, aborta.
                val pkg = e.packageName?.toString()
                if (pkg != null && JarvisCore.taskActive) {
                    val d = SecurityGuard.checkApp(pkg, null)
                    if (d.verdict == SecurityGuard.Verdict.BLOCK) {
                        performGlobalAction(GLOBAL_ACTION_HOME)
                        JarvisCore.abortForSecurity(d.reason)
                    }
                }
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> screenVersion.incrementAndGet()
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        JarvisCore.abortForSecurity("O serviço de acessibilidade foi desativado.")
        JarvisBus.emit("permissions_changed", jo("accessibility" to false))
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun currentPackage(): String? = rootInActiveWindow?.packageName?.toString()

    suspend fun tap(x: Float, y: Float): Boolean =
        dispatch(Path().apply { moveTo(x, y) }, 60)

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 350): Boolean =
        dispatch(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, durationMs)

    private suspend fun dispatch(path: Path, duration: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        val accepted = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!accepted && cont.isActive) cont.resume(false)
    }
}
