package br.jarvis.plugin.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notifier {
    const val CH_LISTEN = "jarvis_listen"
    const val CH_CONFIRM = "jarvis_confirm"
    const val ID_LISTEN = 1001
    const val ID_CONFIRM = 1002

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LISTEN, "Escuta do Jarvis", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_CONFIRM, "Confirmações do Jarvis", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openApp(ctx: Context): PendingIntent {
        val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent()
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun action(ctx: Context, label: String, act: String, id: String?): Notification.Action {
        val i = Intent(ctx, ActionReceiver::class.java).setAction(act).putExtra("id", id)
        val pi = PendingIntent.getBroadcast(ctx, act.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), label, pi).build()
    }

    fun listening(ctx: Context, text: String): Notification {
        ensureChannels(ctx)
        return Notification.Builder(ctx, CH_LISTEN)
            .setContentTitle("JARVIS – microfone ativo")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openApp(ctx))
            .addAction(action(ctx, "Desligar escuta", ActionReceiver.ACTION_STOP_LISTENING, null))
            .build()
    }

    fun showConfirm(ctx: Context, id: String, title: String, desc: String) {
        ensureChannels(ctx)
        val n = Notification.Builder(ctx, CH_CONFIRM)
            .setContentTitle(title)
            .setContentText(desc.lineSequence().firstOrNull() ?: "")
            .setStyle(Notification.BigTextStyle().bigText(desc))
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .addAction(action(ctx, "Confirmar", ActionReceiver.ACTION_CONFIRM, id))
            .addAction(action(ctx, "Cancelar", ActionReceiver.ACTION_DENY, id))
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_CONFIRM, n)
    }

    fun clearConfirm(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_CONFIRM)
    }
}
