package br.jarvis.plugin.automation

import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.jo

class FinishResult(val success: Boolean, val summary: String)

/** Estado de uma tarefa em execução. */
class TaskRun(val id: String, var title: String, val source: String) {
    var started = false
    var usedUi = false
    var lastScreenNorm = ""
    var lastScreenSig = ""
    var lastSeenVersion = 0L
    var screenshotTaken = false
    var finished: FinishResult? = null
    var finishRejections = 0
    var plan: List<String> = emptyList()
    var declined = false
    @Volatile var aborted: String? = null

    fun ensureStarted() {
        if (!started) {
            started = true
            JarvisBus.emit("task_started", jo("id" to id, "title" to title))
        }
    }
}
