package br.jarvis.plugin.controller

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityNodeInfo
import br.jarvis.plugin.accessibility.JarvisAccessibilityService
import br.jarvis.plugin.accessibility.ScreenInspector
import br.jarvis.plugin.accessibility.Snapshot
import br.jarvis.plugin.automation.FinishResult
import br.jarvis.plugin.automation.TaskRun
import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.JarvisCore
import br.jarvis.plugin.core.ja
import br.jarvis.plugin.core.jo
import br.jarvis.plugin.security.ConfirmationGate
import br.jarvis.plugin.security.SecurityGuard
import br.jarvis.plugin.security.SecurityGuard.Sensitive
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * Executor das ferramentas. Toda chamada passa por: validação de schema -> checagem de segurança
 * (banco/fluxo financeiro/restrito) -> confirmação (se sensível) -> execução -> verificação de mudança.
 * A IA nunca chama o sistema diretamente.
 */
object AndroidController {
    private const val TAG = "JarvisController"
    private val shotExecutor = Executors.newSingleThreadExecutor()

    // ---------- helpers de resultado ----------
    private fun ok(vararg p: Pair<String, Any?>): JSONObject = jo("ok" to true, *p)
    private fun err(msg: String, vararg p: Pair<String, Any?>): JSONObject = jo("ok" to false, "error" to msg, *p)
    private fun blocked(reason: String): JSONObject =
        jo("ok" to false, "blocked" to true, "error" to "$reason A tarefa foi interrompida por segurança.")

    suspend fun execute(name: String, args: JSONObject, run: TaskRun): JSONObject {
        val spec = ToolSpecs.byName(name) ?: return err("Ferramenta desconhecida: $name")
        ToolSpecs.validate(spec, args)?.let { return err(it) }
        run.aborted?.let { return err("Tarefa interrompida: $it") }
        return try {
            when (name) {
                "set_plan" -> setPlan(args, run)
                "report_progress" -> reportProgress(args, run)
                "finish_task" -> finishTask(args, run)
                else -> {
                    run.usedUi = true
                    run.ensureStarted()
                    executeUi(name, args, run)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Falha em $name", e)
            err("Falha ao executar $name: ${e.javaClass.simpleName}")
        }
    }

    // ---------- ferramentas de controle da tarefa ----------
    private fun setPlan(a: JSONObject, run: TaskRun): JSONObject {
        run.title = a.getString("title")
        val steps = a.getJSONArray("steps")
        run.plan = (0 until steps.length()).map { steps.getString(it).take(100) }
        run.ensureStarted()
        JarvisBus.emit("task_title", jo("id" to run.id, "title" to run.title))
        JarvisBus.emit("task_plan", jo("id" to run.id, "steps" to ja(run.plan)))
        return ok()
    }

    private fun reportProgress(a: JSONObject, run: TaskRun): JSONObject {
        val i = a.getInt("step_index")
        if (i < 0 || i >= run.plan.size) return err("step_index fora do plano (0..${run.plan.size - 1})")
        JarvisBus.emit("task_step", jo("id" to run.id, "index" to i, "status" to a.getString("status"),
            "note" to a.optString("note", "")))
        return ok()
    }

    private fun finishTask(a: JSONObject, run: TaskRun): JSONObject {
        val success = a.getBoolean("success")
        val summary = a.getString("summary")
        if (success && run.usedUi) {
            val ev = SecurityGuard.norm(a.optString("evidence", ""))
            if (ev.length < 3 || !run.lastScreenNorm.contains(ev)) {
                run.finishRejections++
                if (run.finishRejections >= 2) {
                    run.finished = FinishResult(false, "Não consegui comprovar a conclusão na tela. $summary (não verificado)")
                    return ok("note" to "Encerrada como não verificada.")
                }
                return err("Evidência não encontrada na última leitura da tela. Chame inspect_screen e cite um texto realmente visível que comprove a conclusão.")
            }
        }
        run.finished = FinishResult(success, summary)
        return ok()
    }

    // ---------- ferramentas de interface ----------
    private suspend fun executeUi(name: String, a: JSONObject, run: TaskRun): JSONObject {
        val svc = JarvisAccessibilityService.instance
            ?: return err("O serviço de acessibilidade não está ativo. Peça ao usuário para ativá-lo em Configurações > Acessibilidade.")

        // Abrir/trocar de app: checagem do DESTINO antes de qualquer abertura.
        if (name == "open_app" || name == "switch_app") return openApp(svc, a.getString("app_name"), run)
        if (name == "press_home") { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return settle(svc, run, "home") }

        val pkg = currentPkg(svc) ?: return err("Nenhuma janela ativa acessível. Tente wait_for_screen_change ou press_back.")
        val appDecision = SecurityGuard.checkApp(pkg, JarvisCore.appLabel(pkg))
        when (appDecision.verdict) {
            SecurityGuard.Verdict.BLOCK -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return blocked(appDecision.reason) }
            SecurityGuard.Verdict.RESTRICTED -> if (name != "get_current_app" && name != "press_back")
                return err(appDecision.reason, "restricted" to true)
            else -> {}
        }
        if (name == "get_current_app") return ok("package" to pkg, "label" to JarvisCore.appLabel(pkg))

        // Checagem de fluxo financeiro por conteúdo da tela, antes de ler ou tocar.
        if (name != "press_back" && name != "wait_for_screen_change") {
            val d = SecurityGuard.checkScreenText(ScreenInspector.peekText(svc))
            if (!d.allowed) { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return blocked(d.reason) }
        }

        return when (name) {
            "inspect_screen" -> inspect(svc, run)
            "read_accessible_text" -> {
                val snap = ScreenInspector.snapshot(svc) ?: return err("Tela indisponível.")
                remember(run, snap, svc)
                ok("text" to snap.allText.take(4000), "screen_id" to snap.sig)
            }
            "find_element" -> {
                val snap = ScreenInspector.snapshot(svc) ?: return err("Tela indisponível.")
                remember(run, snap, svc)
                val found = ScreenInspector.find(snap, a.getString("query"), a.optBoolean("only_clickable", false))
                ok("matches" to ja(found.map { ScreenInspector.nodeJson(it) }), "count" to found.size)
            }
            "tap_element" -> tapElement(svc, a.getInt("element_id"), pkg, run)
            "type_text" -> typeText(svc, a, pkg, run)
            "scroll_screen" -> scroll(svc, a, run)
            "press_back" -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); settle(svc, run, "back") }
            "wait_for_screen_change" -> {
                val t = a.optInt("timeout_ms", 3000).coerceIn(500, 10_000).toLong()
                val changed = awaitChange(run.lastSeenVersion, t)
                run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
                ok("changed" to changed)
            }
            "capture_screen" -> capture(svc, run)
            "tap_point" -> tapPoint(svc, a, pkg, run)
            else -> err("Ferramenta não implementada: $name")
        }
    }

    private suspend fun currentPkg(svc: JarvisAccessibilityService): String? {
        repeat(4) { svc.currentPackage()?.let { return it }; delay(150) }
        return null
    }

    private fun remember(run: TaskRun, snap: Snapshot, svc: JarvisAccessibilityService) {
        run.lastScreenNorm = SecurityGuard.norm(snap.allText)
        run.lastScreenSig = snap.sig
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
    }

    private fun inspect(svc: JarvisAccessibilityService, run: TaskRun): JSONObject {
        val snap = ScreenInspector.snapshot(svc) ?: return err("Tela indisponível no momento.")
        val d = SecurityGuard.checkScreenText(snap.allText)
        if (!d.allowed) { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); return blocked(d.reason) }
        remember(run, snap, svc)
        return ok("screen" to ScreenInspector.toJson(snap))
    }

    // ---------- confirmação ----------
    private suspend fun confirmIfSensitive(kind: Sensitive?, pkg: String, target: String, extra: String?): JSONObject? {
        if (kind == null) return null
        val desc = buildString {
            append("Ação: ").append(kind.label)
            append("\nAplicativo: ").append(JarvisCore.appLabel(pkg))
            append("\nElemento: «").append(target.take(80)).append("»")
            if (!extra.isNullOrBlank()) append("\nConteúdo: «").append(extra.take(300)).append("»")
        }
        val approved = ConfirmationGate.request("Confirmar ação sensível", desc)
        return if (approved) null
        else err("O usuário NÃO autorizou esta ação. Não tente de novo nem procure alternativa; encerre a tarefa informando isso.",
            "declined" to true)
    }

    // ---------- toque ----------
    private suspend fun tapElement(svc: JarvisAccessibilityService, id: Int, pkg: String, run: TaskRun): JSONObject {
        val node = ScreenInspector.resolve(id)
            ?: return err("O elemento $id não existe mais ou a tela mudou. Chame inspect_screen novamente.")
        if (!node.enabled) return err("O elemento $id está desabilitado.")
        val snap = ScreenInspector.lastSnapshot
        val kind = SecurityGuard.classifyTarget(node.label, node.viewId)
        confirmIfSensitive(kind, pkg, node.label.ifBlank { node.viewId }, snap?.let { ScreenInspector.draftText(it) })?.let {
            if (it.optBoolean("declined")) run.declined = true
            return it
        }
        val before = JarvisAccessibilityService.screenVersion.get()
        var target: AccessibilityNodeInfo? = node.info
        while (target != null && !target.isClickable) target = target.parent
        var method = "click"
        var done = target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        if (!done) {
            val b = node.bounds
            if (!b.isEmpty && b.centerX() > 0 && b.centerY() > 0) { method = "gesture"; done = svc.tap(b.centerX().toFloat(), b.centerY().toFloat()) }
        }
        if (!done) return err("Não foi possível tocar no elemento $id.")
        val changed = awaitChange(before, 1800)
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
        return ok("method" to method, "screen_changed" to changed)
    }

    private suspend fun tapPoint(svc: JarvisAccessibilityService, a: JSONObject, pkg: String, run: TaskRun): JSONObject {
        if (!run.screenshotTaken) return err("Use capture_screen antes de tap_point.")
        val x = a.getInt("x"); val y = a.getInt("y")
        if (x !in 0..1000 || y !in 0..1000) return err("x e y devem estar entre 0 e 1000.")
        val desc = a.getString("target_description")
        confirmIfSensitive(SecurityGuard.classifyTarget(desc, null), pkg, desc, null)?.let {
            if (it.optBoolean("declined")) run.declined = true
            return it
        }
        val dm = svc.resources.displayMetrics
        val before = JarvisAccessibilityService.screenVersion.get()
        val done = svc.tap(x / 1000f * dm.widthPixels, y / 1000f * dm.heightPixels)
        if (!done) return err("O gesto foi cancelado pelo sistema.")
        val changed = awaitChange(before, 1800)
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
        return ok("screen_changed" to changed)
    }

    // ---------- digitação ----------
    private suspend fun typeText(svc: JarvisAccessibilityService, a: JSONObject, pkg: String, run: TaskRun): JSONObject {
        val text = a.getString("text")
        val id = a.optInt("element_id", -1)
        val node: AccessibilityNodeInfo = if (id >= 0) {
            val n = ScreenInspector.resolve(id) ?: return err("O campo $id não existe mais. Chame inspect_screen novamente.")
            if (!n.editable) return err("O elemento $id não é um campo de texto.")
            if (n.password) return err("Campo de senha: a digitação é bloqueada por segurança.")
            if (!n.info.isFocused) { n.info.performAction(AccessibilityNodeInfo.ACTION_FOCUS); n.info.performAction(AccessibilityNodeInfo.ACTION_CLICK); delay(200) }
            n.info
        } else {
            val f = svc.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: return err("Nenhum campo de texto em foco. Use tap_element em um campo primeiro.")
            if (f.isPassword) return err("Campo de senha: a digitação é bloqueada por segurança.")
            f
        }
        val current = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val newText = if (a.optBoolean("append", false)) current + text else text
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText) }
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return err("O app recusou a digitação neste campo.")
        var submitted = false
        if (a.optBoolean("submit", false)) {
            val hint = listOfNotNull(node.hintText?.toString(), node.contentDescription?.toString(), node.viewIdResourceName).joinToString(" ")
            confirmIfSensitive(SecurityGuard.classifySubmitField(hint), pkg, "Enter/Enviar no campo", newText)?.let {
                if (it.optBoolean("declined")) run.declined = true
                return it
            }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return err("Enter via acessibilidade exige Android 11+. Toque no botão de busca/enviar.")
            val before = JarvisAccessibilityService.screenVersion.get()
            submitted = node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            if (!submitted) return err("Texto digitado, mas o app não aceitou Enter. Toque no botão de busca/enviar.", "typed" to true)
            awaitChange(before, 1800)
        } else delay(250)
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
        return ok("typed_chars" to text.length, "submitted" to submitted)
    }

    // ---------- rolagem ----------
    private suspend fun scroll(svc: JarvisAccessibilityService, a: JSONObject, run: TaskRun): JSONObject {
        val dir = a.getString("direction")
        val id = a.optInt("element_id", -1)
        val snap = ScreenInspector.lastSnapshot ?: ScreenInspector.snapshot(svc) ?: return err("Tela indisponível.")
        val node = if (id >= 0) ScreenInspector.resolve(id) else
            snap.nodes.filter { it.scrollable }.maxByOrNull { it.bounds.width().toLong() * it.bounds.height() }?.let { ScreenInspector.resolve(it.id) }
        val before = JarvisAccessibilityService.screenVersion.get()
        val action = when (dir) {
            "down" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id
            "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id
            "left" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id
            else -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id
        }
        var done = node?.info?.performAction(action) ?: false
        var method = "action"
        if (!done) {
            method = "swipe"
            val dm = svc.resources.displayMetrics
            val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
            done = when (dir) {
                "down" -> svc.swipe(w / 2, h * 0.70f, w / 2, h * 0.30f)
                "up" -> svc.swipe(w / 2, h * 0.30f, w / 2, h * 0.70f)
                "left" -> svc.swipe(w * 0.25f, h / 2, w * 0.75f, h / 2)
                else -> svc.swipe(w * 0.75f, h / 2, w * 0.25f, h / 2)
            }
        }
        if (!done) return err("Não foi possível rolar a tela.")
        val changed = awaitChange(before, 1200)
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
        return ok("method" to method, "screen_changed" to changed, "hint" to if (!changed) "Provavelmente chegou ao fim da lista." else "")
    }

    // ---------- abrir apps ----------
    private suspend fun openApp(svc: JarvisAccessibilityService, query: String, run: TaskRun): JSONObject {
        val ctx = JarvisCore.appCtx
        val matches = AppResolver.resolve(ctx, query)
        if (matches.isEmpty()) {
            // Mesmo sem app instalado, nomes bancários nunca passam.
            val d = SecurityGuard.checkApp(query, query)
            if (d.verdict == SecurityGuard.Verdict.BLOCK) return blocked(d.reason)
            return err("Nenhum app instalado corresponde a \"$query\".")
        }
        val app = matches.first()
        val d = SecurityGuard.checkApp(app.pkg, app.label)
        if (d.verdict == SecurityGuard.Verdict.BLOCK) return blocked(d.reason)
        val intent = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return err("O app ${app.label} não pode ser aberto.")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val before = JarvisAccessibilityService.screenVersion.get()
        try { svc.startActivity(intent) } catch (e: Exception) { return err("O Android impediu a abertura de ${app.label}.") }
        val end = System.currentTimeMillis() + 5000
        while (System.currentTimeMillis() < end) {
            if (svc.currentPackage() == app.pkg) break
            delay(200)
        }
        val now = svc.currentPackage()
        if (now != app.pkg) return err("${app.label} não chegou ao primeiro plano (app atual: ${now ?: "desconhecido"}).")
        delay(600)
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
        return ok("opened" to app.label, "package" to app.pkg, "screen_changed" to (JarvisAccessibilityService.screenVersion.get() != before),
            "other_matches" to ja(matches.drop(1).map { it.label }))
    }

    // ---------- verificação de mudança ----------
    private suspend fun awaitChange(since: Long, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (JarvisAccessibilityService.screenVersion.get() != since) { delay(350); return true }
            delay(120)
        }
        return false
    }

    private suspend fun settle(svc: JarvisAccessibilityService, run: TaskRun, what: String): JSONObject {
        val before = run.lastSeenVersion
        val changed = awaitChange(before, 1500)
        run.lastSeenVersion = JarvisAccessibilityService.screenVersion.get()
        return ok("action" to what, "screen_changed" to changed)
    }

    // ---------- análise visual (captura autorizada) ----------
    private suspend fun capture(svc: JarvisAccessibilityService, run: TaskRun): JSONObject {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return err("Captura de tela via acessibilidade exige Android 11+.")
        val bmp: Bitmap = suspendCancellableCoroutine { cont ->
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, shotExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val copy = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    if (cont.isActive) cont.resume(copy ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888))
                }
                override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)) }
            })
        }
        if (bmp.width <= 1) return err("Captura indisponível (janela protegida ou limite de frequência). Use inspect_screen.")
        val scale = 768f / bmp.width
        val small = Bitmap.createScaledBitmap(bmp, 768, (bmp.height * scale).toInt().coerceAtLeast(1), true)
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 60, out)
        run.screenshotTaken = true
        return ok("mime" to "image/jpeg", "width" to small.width, "height" to small.height,
            "image_base64" to Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP),
            "note" to "Use coordenadas normalizadas 0-1000 em tap_point.")
    }
}
