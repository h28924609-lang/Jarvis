package br.jarvis.plugin.voice

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.JarvisConfig
import br.jarvis.plugin.core.JarvisCore
import br.jarvis.plugin.core.Notifier
import br.jarvis.plugin.core.jo

/**
 * Serviço em primeiro plano (tipo microfone) com notificação persistente e botão para desligar.
 * Só é iniciado por ação explícita do usuário no app. Não grava áudio: apenas reconhece fala.
 */
class VoiceService : Service() {
    companion object {
        const val ACTION_START_WAKE = "br.jarvis.voice.START_WAKE"
        const val ACTION_LISTEN_ONCE = "br.jarvis.voice.LISTEN_ONCE"
        const val ACTION_STOP = "br.jarvis.voice.STOP"
        @Volatile var instance: VoiceService? = null

        fun hasMic(ctx: Context) =
            ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        fun startWake(ctx: Context) = send(ctx, ACTION_START_WAKE)
        fun listenOnce(ctx: Context) = send(ctx, ACTION_LISTEN_ONCE)
        fun stop(ctx: Context) { JarvisConfig.init(ctx); JarvisConfig.wakeEnabled = false; ctx.stopService(Intent(ctx, VoiceService::class.java)) }

        private fun send(ctx: Context, action: String) {
            if (!hasMic(ctx)) {
                JarvisBus.emit("message", jo("role" to "assistant", "text" to "Conceda a permissão de microfone em Configurações."))
                return
            }
            ctx.startForegroundService(Intent(ctx, VoiceService::class.java).setAction(action))
        }

        /** Chamado ao fim de uma tarefa/fala: retoma a palavra de ativação se o usuário a mantém ligada. */
        fun resumeIfWanted(ctx: Context) {
            val s = instance
            if (s != null) s.resumeWake() else JarvisBus.emit("state", jo("state" to "idle"))
        }
    }

    private var engine: VoiceEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        JarvisCore.init(applicationContext)
        instance = this
        engine = VoiceEngine(applicationContext,
            onCommand = { text -> engine?.stop(); JarvisCore.submitCommand(text, "voice") },
            onIdle = { resumeWake() })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stop(this); return START_NOT_STICKY }
            ACTION_START_WAKE -> { goForeground("Aguardando a palavra \"Jarvis\""); JarvisConfig.wakeEnabled = true; acquireLock(); engine?.start(VoiceEngine.Mode.WAKE); listening(true) }
            ACTION_LISTEN_ONCE -> { goForeground("Ouvindo seu comando"); acquireLock(); engine?.start(VoiceEngine.Mode.COMMAND); listening(true) }
        }
        return START_NOT_STICKY
    }

    private fun goForeground(text: String) {
        val n = Notifier.listening(this, text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            startForeground(Notifier.ID_LISTEN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(Notifier.ID_LISTEN, n)
    }

    private fun acquireLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:listen").apply { acquire(8 * 60 * 60 * 1000L) }
    }

    private fun listening(on: Boolean) = JarvisBus.emit("listening_changed", jo("active" to on))

    fun resumeWake() {
        if (JarvisConfig.wakeEnabled && !JarvisCore.taskActive) {
            goForeground("Aguardando a palavra \"Jarvis\""); engine?.start(VoiceEngine.Mode.WAKE); listening(true)
        } else {
            stopSelf()
        }
        JarvisBus.emit("state", jo("state" to "idle"))
    }

    override fun onDestroy() {
        engine?.stop(); engine = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        instance = null
        listening(false)
        super.onDestroy()
    }
}
