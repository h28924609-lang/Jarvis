package br.jarvis.plugin.core

import android.content.Context
import android.content.SharedPreferences
import br.jarvis.plugin.security.SecurityGuard

/** Configurações locais. NUNCA armazena a chave Gemini: só URL do servidor e token do app. */
object JarvisConfig {
    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        SecurityGuard.setSelfPackage(ctx.packageName)
        SecurityGuard.addExtraBlocked(extraBlocked)
    }

    private fun p() = prefs ?: error("JarvisConfig não inicializado")

    var serverUrl: String
        get() = p().getString("server_url", "") ?: ""
        set(v) { p().edit().putString("server_url", v.trim()).apply() }

    var token: String
        get() = p().getString("token", "") ?: ""
        set(v) { p().edit().putString("token", v.trim()).apply() }

    var speakReplies: Boolean
        get() = p().getBoolean("speak", true)
        set(v) { p().edit().putBoolean("speak", v).apply() }

    var wakeEnabled: Boolean
        get() = p().getBoolean("wake", false)
        set(v) { p().edit().putBoolean("wake", v).apply() }

    var extraBlocked: Set<String>
        get() = p().getStringSet("extra_blocked", emptySet()) ?: emptySet()
        set(v) { p().edit().putStringSet("extra_blocked", v).apply() }

    /** Exige HTTPS: o Android bloqueia tráfego em texto puro e o token não deve trafegar aberto. */
    val isAiConfigured: Boolean get() = serverUrl.startsWith("https://") && token.isNotBlank()
}
