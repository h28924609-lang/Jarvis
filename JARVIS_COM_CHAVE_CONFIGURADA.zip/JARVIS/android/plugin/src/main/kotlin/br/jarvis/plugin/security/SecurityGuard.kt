package br.jarvis.plugin.security

import java.text.Normalizer
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Proteções aplicadas pelo próprio executor, independentes de qualquer instrução da IA.
 * - BLOCK: app bancário/financeiro ou tela com fluxo financeiro. Aborta a tarefa.
 * - RESTRICTED: telas que o Jarvis não deve operar (instalador, diálogos de permissão, o próprio app).
 * Estas listas só podem CRESCER em tempo de execução (addExtraBlocked); nunca encolher.
 */
object SecurityGuard {
    enum class Verdict { ALLOW, BLOCK, RESTRICTED }
    data class Decision(val verdict: Verdict, val reason: String = "") {
        val allowed: Boolean get() = verdict == Verdict.ALLOW
    }

    enum class Sensitive(val label: String) {
        MENSAGEM("enviar uma mensagem"),
        PUBLICACAO("publicar conteúdo"),
        EXCLUSAO("excluir ou apagar"),
        COMPRA("confirmar compra ou assinatura"),
        CADASTRO("fazer inscrição ou cadastro"),
        DADOS("compartilhar informações"),
        GRAVACAO("iniciar uma gravação"),
        LIGACAO("fazer uma ligação")
    }

    @Volatile private var selfPackage: String = "br.jarvis.assistant"
    private val extraBlocked = CopyOnWriteArraySet<String>()

    fun setSelfPackage(p: String) { selfPackage = p.lowercase() }
    fun addExtraBlocked(pkgs: Collection<String>) { pkgs.map { it.trim().lowercase() }.filter { it.isNotEmpty() }.forEach { extraBlocked.add(it) } }

    fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .lowercase()
            .replace(Regex("\\s+"), " ")
            .trim()

    // Lista inicial (não exaustiva). Complementada pelas heurísticas abaixo e pelo bloqueio por tela.
    private val BANK_PACKAGES = setOf(
        "com.nu.production", "com.itau", "com.bradesco", "br.com.bb.android", "com.santander.app",
        "br.com.gabba.caixa", "br.gov.caixa.tem", "br.com.intermedium", "com.c6bank.app",
        "br.com.original.bank", "com.picpay", "com.mercadopago.wallet", "br.com.neon",
        "com.google.android.apps.nbu.paisa.user", "com.google.android.apps.walletnfcrel",
        "com.samsung.android.spay", "com.paypal.android.p2pmobile", "com.binance.dev",
        "com.coinbase.android", "br.com.sicredi.mobile", "br.com.sicoobnet.sicoobapp"
    )

    private val BANK_PKG_REGEX = Regex(
        "bank|banco|wallet|nubank|itau|bradesco|santander|sicredi|sicoob|banrisul|picpay|mercadopago|" +
            "pagseguro|pagbank|c6bank|spay|paypal|binance|coinbase|mercadobitcoin|fintech"
    )

    private val BANK_LABEL_REGEX = Regex(
        "\\b(banco|bank|nubank|itau|bradesco|santander|caixa economica|caixa tem|sicredi|sicoob|banrisul|" +
            "picpay|mercado ?pago|pagbank|pagseguro|c6 ?bank|btg|safra|binance|coinbase|wallet|carteira|" +
            "samsung pay|paypal|pix)\\b"
    )

    private val RESTRICTED_PACKAGES = setOf(
        "com.google.android.permissioncontroller", "com.android.permissioncontroller",
        "com.google.android.packageinstaller", "com.android.packageinstaller",
        "com.samsung.android.packageinstaller"
    )

    fun checkApp(pkg: String, label: String?): Decision {
        val p = pkg.lowercase()
        if (p in BANK_PACKAGES || p in extraBlocked || BANK_PKG_REGEX.containsMatchIn(p))
            return Decision(Verdict.BLOCK, "Aplicativo bancário/financeiro bloqueado ($pkg).")
        if (label != null) {
            val l = norm(label)
            if (BANK_LABEL_REGEX.containsMatchIn(l) || l == "inter" || l == "banco inter")
                return Decision(Verdict.BLOCK, "Aplicativo bancário/financeiro bloqueado ($label).")
        }
        if (p == selfPackage) return Decision(Verdict.RESTRICTED, "O Jarvis não opera o próprio aplicativo. Abra outro app.")
        if (p in RESTRICTED_PACKAGES)
            return Decision(Verdict.RESTRICTED, "Esta tela (permissões/instalação) deve ser operada somente pelo usuário.")
        return Decision(Verdict.ALLOW)
    }

    private val STRONG_FIN = listOf(
        "chave pix", "pix copia e cola", "copia e cola", "boleto", "codigo de barras", "linha digitavel",
        "transferir para", "confirmar transferencia", "extrato", "saldo disponivel", "fatura do cartao",
        "numero do cartao", "codigo de seguranca", "cvv", "agencia e conta"
    )
    private val WEAK_FIN = listOf("pix", "transferencia", "transferir", "saldo", "limite disponivel", "cartao de credito")

    /** Detecta fluxos financeiros dentro de qualquer app a partir do texto visível. */
    fun checkScreenText(text: String): Decision {
        val t = " " + norm(text) + " "
        STRONG_FIN.firstOrNull { t.contains(it) }?.let {
            return Decision(Verdict.BLOCK, "Fluxo financeiro identificado na tela; operação bloqueada.")
        }
        val weak = WEAK_FIN.count { Regex("\\b" + Regex.escape(it) + "\\b").containsMatchIn(t) }
        if (weak >= 2) return Decision(Verdict.BLOCK, "Fluxo financeiro identificado na tela; operação bloqueada.")
        return Decision(Verdict.ALLOW)
    }

    private val FIN_REQUEST = Regex(
        "\\b(banco(?! de (dados|imagens|horas|sangue|praca|areia))|nubank|itau|bradesco|santander|sicredi|sicoob|" +
            "picpay|mercado ?pago|pix|transferir|transferencia|boleto|extrato|saldo|fatura do cartao)\\b"
    )

    /** Triagem do pedido do usuário ANTES de chamar a IA. */
    fun checkUserRequest(text: String): Decision =
        if (FIN_REQUEST.containsMatchIn(norm(text)))
            Decision(Verdict.BLOCK, "Não posso abrir aplicativos bancários nem realizar operações financeiras.")
        else Decision(Verdict.ALLOW)

    private val SENSITIVE: List<Pair<Sensitive, Regex>> = listOf(
        Sensitive.MENSAGEM to Regex("\\b(enviar|send|responder|reply|encaminhar|forward)\\b"),
        Sensitive.PUBLICACAO to Regex("\\b(publicar|postar|post|publish|tweetar)\\b"),
        Sensitive.EXCLUSAO to Regex("\\b(excluir|apagar|deletar|delete|remover|remove|limpar tudo|esvaziar|descartar|discard|clear all)\\b"),
        Sensitive.COMPRA to Regex("\\b(comprar|buy|buy now|purchase|finalizar compra|confirmar pedido|fazer pedido|place order|assinar|pagar agora)\\b"),
        Sensitive.CADASTRO to Regex("\\b(inscrever|inscrever-se|inscricao|cadastrar|cadastre-se|criar conta|registrar|sign up|register|subscribe)\\b"),
        Sensitive.DADOS to Regex("\\b(compartilhar|share|enviar localizacao)\\b"),
        Sensitive.GRAVACAO to Regex("\\b(gravar|gravacao|iniciar gravacao|record|start recording|rec)\\b"),
        Sensitive.LIGACAO to Regex("\\b(ligar|call|chamar|videochamada)\\b")
    )
    private val VIEW_ID_TOKENS = mapOf(
        "send" to Sensitive.MENSAGEM, "publish" to Sensitive.PUBLICACAO, "delete" to Sensitive.EXCLUSAO,
        "buy" to Sensitive.COMPRA, "purchase" to Sensitive.COMPRA, "subscribe" to Sensitive.CADASTRO,
        "signup" to Sensitive.CADASTRO, "record" to Sensitive.GRAVACAO
    )

    /** Classifica um elemento-alvo como ação sensível (exige confirmação) ou null. */
    fun classifyTarget(label: String?, viewId: String?): Sensitive? {
        if (!label.isNullOrBlank()) {
            val l = norm(label)
            SENSITIVE.firstOrNull { it.second.containsMatchIn(l) }?.let { return it.first }
        }
        if (!viewId.isNullOrBlank()) {
            val tokens = norm(viewId).split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
            tokens.firstNotNullOfOrNull { VIEW_ID_TOKENS[it] }?.let { return it }
        }
        return null
    }

    private val MESSAGE_FIELD_HINT = Regex("\\b(mensagem|message|comentario|comment|responder|reply|escreva|postar|post)\\b")
    /** Enviar (IME enter) em campos que parecem de mensagem/comentário é sensível. */
    fun classifySubmitField(hintOrDesc: String?): Sensitive? =
        if (!hintOrDesc.isNullOrBlank() && MESSAGE_FIELD_HINT.containsMatchIn(norm(hintOrDesc))) Sensitive.MENSAGEM else null
}
