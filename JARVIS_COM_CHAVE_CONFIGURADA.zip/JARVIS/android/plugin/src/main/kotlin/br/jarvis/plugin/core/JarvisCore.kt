package br.jarvis.plugin.core

import android.content.Context
import br.jarvis.plugin.accessibility.JarvisAccessibilityService
import br.jarvis.plugin.ai.AiException
import br.jarvis.plugin.ai.JarvisAI
import br.jarvis.plugin.automation.AgentLoop
import br.jarvis.plugin.automation.TaskRun
import br.jarvis.plugin.controller.AppResolver
import br.jarvis.plugin.security.ConfirmationGate
import br.jarvis.plugin.security.SecurityGuard
import br.jarvis.plugin.voice.VoiceService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID

/** Orquestrador: recebe comandos (texto/voz), roda uma tarefa por vez e publica eventos para a interface. */
object JarvisCore {
    private const val MAX_TASK_MS = 5 * 60_000L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile private var job: Job? = null
    @Volatile var currentRun: TaskRun? = null
    private val chatHistory = ArrayDeque<Pair<String, String>>()
    private val labelCache = HashMap<String, String>()

    lateinit var appCtx: Context
        private set

    @Synchronized
    fun init(ctx: Context) {
        if (!::appCtx.isInitialized) appCtx = ctx.applicationContext
        JarvisConfig.init(ctx)
    }

    val taskActive: Boolean get() = job?.isActive == true

    fun appLabel(pkg: String): String =
        synchronized(labelCache) { labelCache.getOrPut(pkg) { AppResolver.labelOf(appCtx, pkg) ?: pkg } }

    fun state(s: String) = JarvisBus.emit("state", jo("state" to s))

    private fun message(role: String, text: String) = JarvisBus.emit("message", jo("role" to role, "text" to text))

    private fun say(text: String, source: String) {
        message("assistant", text)
        if (source == "voice" && JarvisConfig.speakReplies) Speaker.speak(appCtx, text) { VoiceService.resumeIfWanted(appCtx) }
        else VoiceService.resumeIfWanted(appCtx)
    }

    fun submitCommand(text: String, source: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (taskActive) { message("assistant", "Já estou executando uma tarefa. Cancele-a antes de pedir outra."); return }
        message("user", t)
        val screen = SecurityGuard.checkUserRequest(t)
        if (!screen.allowed) { say(screen.reason, source); return }
        if (!JarvisConfig.isAiConfigured) {
            say("A IA ainda não está configurada. Abra as configurações e informe a URL HTTPS do servidor seguro e o token.", source); return
        }
        job = scope.launch { runCommand(t, source) }
    }

    private suspend fun runCommand(text: String, source: String) {
        val run = TaskRun(UUID.randomUUID().toString().take(8), text.take(60), source)
        currentRun = run
        state("processing")
        var success = false
        var summary: String
        try {
            val r = withTimeout(MAX_TASK_MS) { AgentLoop.run(run, text, chatHistory.toList()) }
            success = r.first; summary = r.second
        } catch (e: TimeoutCancellationException) {
            summary = "Tempo máximo da tarefa excedido."
        } catch (e: CancellationException) {
            summary = run.aborted ?: "Tarefa cancelada."
        } catch (e: AiException) {
            summary = e.userMessage
            JarvisBus.emit("ai_status", jo("connected" to false, "text" to e.userMessage))
        } catch (e: Exception) {
            summary = "Erro inesperado: ${e.javaClass.simpleName}"
        }
        withContext(kotlinx.coroutines.NonCancellable) {
            ConfirmationGate.denyAll()
            if (run.started) JarvisBus.emit("task_finished", jo("id" to run.id, "success" to success, "summary" to summary))
            chatHistory.addLast("user" to text); chatHistory.addLast("assistant" to summary)
            while (chatHistory.size > 12) chatHistory.removeFirst()
            currentRun = null
            state(if (success || run.finished != null) "idle" else "error")
            say(summary, source)
        }
    }

    fun cancelTask() {
        currentRun?.aborted = "Tarefa cancelada pelo usuário."
        ConfirmationGate.denyAll()
        job?.cancel()
    }

    fun abortForSecurity(reason: String) {
        if (!taskActive) return
        currentRun?.aborted = reason
        ConfirmationGate.denyAll()
        job?.cancel()
    }

    fun testConnection() {
        scope.launch {
            val e = withContext(Dispatchers.IO) { JarvisAI.ping() }
            JarvisBus.emit("ai_status", jo("connected" to (e == null), "text" to (e ?: "Conectado ao servidor de IA")))
        }
    }

    fun accessibilityEnabled(): Boolean {
        if (JarvisAccessibilityService.instance != null) return true
        val enabled = android.provider.Settings.Secure.getString(appCtx.contentResolver,
            android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains(appCtx.packageName + "/" + JarvisAccessibilityService::class.java.name)
    }
}
