package br.jarvis.plugin.controller

import android.content.Context
import android.content.Intent
import br.jarvis.plugin.security.SecurityGuard

data class AppInfo(val pkg: String, val label: String)

object AppResolver {
    fun launchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.pkg }
    }

    fun labelOf(ctx: Context, pkg: String): String? = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { null }

    /** Retorna os melhores candidatos para o nome/pacote pedido (mais provável primeiro). */
    fun resolve(ctx: Context, query: String): List<AppInfo> {
        val q = SecurityGuard.norm(query)
        if (q.isEmpty()) return emptyList()
        val apps = launchable(ctx)
        if (q.contains('.')) apps.firstOrNull { it.pkg.equals(query.trim(), true) }?.let { return listOf(it) }
        return apps.mapNotNull { a ->
            val l = SecurityGuard.norm(a.label)
            val score = when {
                l == q -> 4
                l.startsWith(q) -> 3
                l.contains(q) -> 2
                q.contains(l) && l.length >= 3 -> 1
                else -> 0
            }
            if (score == 0) null else Pair(score, a)
        }.sortedByDescending { it.first }.map { it.second }.take(5)
    }
}
