package br.jarvis.plugin.security

import br.jarvis.plugin.core.JarvisBus
import br.jarvis.plugin.core.JarvisCore
import br.jarvis.plugin.core.Notifier
import br.jarvis.plugin.core.jo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Porta de confirmação. Só a interface (tela ou notificação) resolve uma confirmação;
 * a IA não tem ferramenta para aprová-la.
 */
object ConfirmationGate {
    private val pending = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()

    suspend fun request(title: String, description: String, timeoutMs: Long = 60_000): Boolean {
        val id = UUID.randomUUID().toString().take(8)
        val d = CompletableDeferred<Boolean>()
        pending[id] = d
        JarvisBus.emit("confirm_request", jo("id" to id, "title" to title, "description" to description))
        runCatching { Notifier.showConfirm(JarvisCore.appCtx, id, title, description) }
        try {
            return withTimeoutOrNull(timeoutMs) { d.await() } == true
        } finally {
            pending.remove(id)
            runCatching { Notifier.clearConfirm(JarvisCore.appCtx) }
            JarvisBus.emit("confirm_closed", jo("id" to id))
        }
    }

    fun resolve(id: String, approved: Boolean) { pending[id]?.complete(approved) }
    fun denyAll() { pending.values.forEach { it.complete(false) } }
}
