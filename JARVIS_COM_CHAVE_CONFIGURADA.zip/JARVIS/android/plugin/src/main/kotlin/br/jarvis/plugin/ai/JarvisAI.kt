package br.jarvis.plugin.ai

import br.jarvis.plugin.core.JarvisConfig
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiException(val userMessage: String) : Exception(userMessage)

/**
 * Cliente do servidor intermediário seguro. A chave Gemini vive SOMENTE no servidor;
 * o app envia apenas um token próprio do app. Sem servidor configurado, nada é simulado.
 */
object JarvisAI {
    private fun base() = JarvisConfig.serverUrl.trimEnd('/')

    private fun open(path: String, method: String): HttpURLConnection {
        val c = URL(base() + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10_000
        c.readTimeout = 70_000
        c.setRequestProperty("Authorization", "Bearer " + JarvisConfig.token)
        c.setRequestProperty("Content-Type", "application/json")
        return c
    }

    private fun mapError(code: Int): AiException = when (code) {
        401, 403 -> AiException("O servidor recusou o token do app. Verifique em Configurações.")
        429 -> AiException("Limite de uso do servidor atingido. Tente novamente em instantes.")
        in 500..599 -> AiException("O servidor de IA está com problemas (HTTP $code).")
        else -> AiException("Resposta inesperada do servidor (HTTP $code).")
    }

    /** Uma rodada de raciocínio: retorna a mensagem do assistente (content e/ou tool_calls). Bloqueante. */
    fun step(messages: JSONArray, tools: JSONArray): JSONObject {
        if (!JarvisConfig.isAiConfigured) throw AiException("A IA não está configurada. Informe a URL HTTPS do servidor e o token em Configurações.")
        try {
            val c = open("/v1/agent/step", "POST")
            c.doOutput = true
            c.outputStream.use { it.write(JSONObject().put("messages", messages).put("tools", tools).toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) throw mapError(code)
            val text = c.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(text).getJSONObject("message")
        } catch (e: AiException) {
            throw e
        } catch (e: java.io.IOException) {
            throw AiException("Sem conexão com o servidor de IA.")
        } catch (e: org.json.JSONException) {
            throw AiException("Resposta inválida do servidor de IA.")
        }
    }

    /** Testa a conexão (GET /health autenticado). Retorna null se OK, ou a mensagem de erro. */
    fun ping(): String? {
        if (!JarvisConfig.isAiConfigured) return "Servidor não configurado (use uma URL https:// e um token)."
        return try {
            val c = open("/health", "GET")
            if (c.responseCode == 200) null else mapError(c.responseCode).userMessage
        } catch (e: java.io.IOException) {
            "Sem conexão com o servidor."
        }
    }
}
