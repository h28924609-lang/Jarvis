package br.jarvis.plugin.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import br.jarvis.plugin.security.ConfirmationGate
import br.jarvis.plugin.voice.VoiceService

/** Recebe apenas ações das notificações do próprio app (não exportado). */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        JarvisCore.init(context)
        val id = intent.getStringExtra("id")
        when (intent.action) {
            ACTION_STOP_LISTENING -> VoiceService.stop(context)
            ACTION_CONFIRM -> if (id != null) ConfirmationGate.resolve(id, true)
            ACTION_DENY -> if (id != null) ConfirmationGate.resolve(id, false)
        }
    }

    companion object {
        const val ACTION_STOP_LISTENING = "br.jarvis.action.STOP_LISTENING"
        const val ACTION_CONFIRM = "br.jarvis.action.CONFIRM"
        const val ACTION_DENY = "br.jarvis.action.DENY"
    }
}
