package br.jarvis.plugin.controller

import org.json.JSONArray
import org.json.JSONObject

data class Param(
    val name: String,
    val type: String, // string | integer | boolean | array
    val desc: String,
    val required: Boolean = false,
    val enum: List<String>? = null,
    val max: Int? = null
)

data class ToolSpec(val name: String, val description: String, val params: List<Param>, val touchesUi: Boolean)

/** Catálogo fechado de ferramentas expostas à IA. Qualquer outra chamada é rejeitada. */
object ToolSpecs {
    val all: List<ToolSpec> = listOf(
        ToolSpec("get_current_app", "Retorna o app em primeiro plano (pacote e nome).", emptyList(), true),
        ToolSpec("inspect_screen",
            "Lê a tela atual e devolve elementos numerados (id, texto, tipo, clicável...). Use antes de agir e para verificar o resultado.",
            emptyList(), true),
        ToolSpec("find_element", "Procura elementos na tela atual por texto, descrição ou id de view.",
            listOf(Param("query", "string", "Texto a procurar", true, max = 100),
                Param("only_clickable", "boolean", "Somente elementos clicáveis/editáveis")), true),
        ToolSpec("tap_element", "Toca (ACTION_CLICK) em um elemento da última inspeção. Ações sensíveis pedem confirmação ao usuário automaticamente.",
            listOf(Param("element_id", "integer", "id do elemento retornado por inspect_screen/find_element", true)), true),
        ToolSpec("type_text", "Digita texto em um campo (ACTION_SET_TEXT). Sem element_id usa o campo em foco. Nunca digita em campo de senha.",
            listOf(Param("text", "string", "Texto a digitar", true, max = 2000),
                Param("element_id", "integer", "Campo de texto alvo"),
                Param("append", "boolean", "Acrescentar ao texto existente (padrão: substituir)"),
                Param("submit", "boolean", "Acionar a ação do teclado (Enter/Pesquisar) após digitar")), true),
        ToolSpec("scroll_screen", "Rola a tela ou um elemento rolável.",
            listOf(Param("direction", "string", "Direção do conteúdo a revelar", true, enum = listOf("up", "down", "left", "right")),
                Param("element_id", "integer", "Elemento rolável (padrão: maior área rolável)")), true),
        ToolSpec("press_back", "Aciona o botão Voltar.", emptyList(), true),
        ToolSpec("press_home", "Vai para a tela inicial.", emptyList(), true),
        ToolSpec("open_app", "Abre um app instalado pelo nome (ex.: YouTube, Configurações) ou pacote.",
            listOf(Param("app_name", "string", "Nome ou pacote do app", true, max = 100)), true),
        ToolSpec("switch_app", "Volta para um app já aberto em segundo plano, pelo nome.",
            listOf(Param("app_name", "string", "Nome ou pacote do app", true, max = 100)), true),
        ToolSpec("wait_for_screen_change", "Aguarda a tela mudar (até timeout_ms) e retorna se mudou.",
            listOf(Param("timeout_ms", "integer", "Tempo máximo em ms (500 a 10000)")), true),
        ToolSpec("read_accessible_text", "Retorna todo o texto visível da tela (sem campos de senha).", emptyList(), true),
        ToolSpec("capture_screen",
            "Captura a tela (somente janelas não protegidas) para análise visual quando a estrutura de acessibilidade for insuficiente.",
            listOf(Param("reason", "string", "Por que a captura é necessária", true, max = 200)), true),
        ToolSpec("tap_point", "Toque por coordenadas normalizadas (0 a 1000) da última captura. Último recurso; exige capture_screen antes.",
            listOf(Param("x", "integer", "0 a 1000", true), Param("y", "integer", "0 a 1000", true),
                Param("target_description", "string", "O que está sendo tocado", true, max = 150)), true),
        ToolSpec("set_plan", "Declara o plano da tarefa (3 a 10 etapas curtas). Chame no início de tarefas com várias etapas.",
            listOf(Param("title", "string", "Título curto da tarefa", true, max = 80),
                Param("steps", "array", "Etapas em ordem", true, max = 10)), false),
        ToolSpec("report_progress", "Atualiza o status de uma etapa do plano.",
            listOf(Param("step_index", "integer", "Índice da etapa (começa em 0)", true),
                Param("status", "string", "Novo status", true, enum = listOf("running", "done", "failed")),
                Param("note", "string", "Observação curta", max = 150)), false),
        ToolSpec("finish_task", "Encerra a tarefa. Para success=true em tarefas de tela, 'evidence' DEVE ser um texto realmente visível na tela atual que comprove a conclusão.",
            listOf(Param("success", "boolean", "A tarefa foi concluída e verificada?", true),
                Param("summary", "string", "Resumo para o usuário, em português", true, max = 400),
                Param("evidence", "string", "Texto visível na tela que comprova a conclusão", max = 120)), false)
    )

    private val index = all.associateBy { it.name }
    fun byName(n: String): ToolSpec? = index[n]

    fun toOpenAi(): JSONArray {
        val arr = JSONArray()
        for (t in all) {
            val props = JSONObject()
            val required = JSONArray()
            for (p in t.params) {
                val o = JSONObject().put("type", p.type).put("description", p.desc)
                if (p.type == "array") o.put("items", JSONObject().put("type", "string"))
                if (p.enum != null) o.put("enum", JSONArray(p.enum))
                props.put(p.name, o)
                if (p.required) required.put(p.name)
            }
            val params = JSONObject().put("type", "object").put("properties", props)
                .put("required", required).put("additionalProperties", false)
            arr.put(JSONObject().put("type", "function").put("function",
                JSONObject().put("name", t.name).put("description", t.description).put("parameters", params)))
        }
        return arr
    }

    /** Valida os argumentos contra o schema. Retorna mensagem de erro ou null. */
    fun validate(spec: ToolSpec, args: JSONObject): String? {
        for (p in spec.params) {
            if (!args.has(p.name) || args.isNull(p.name)) {
                if (p.required) return "Parâmetro obrigatório ausente: ${p.name}"
                continue
            }
            val v = args.get(p.name)
            when (p.type) {
                "string" -> {
                    if (v !is String) return "${p.name} deve ser texto"
                    val max = p.max
                    if (max != null && v.length > max) return "${p.name} excede $max caracteres"
                    val en = p.enum
                    if (en != null && v !in en) return "${p.name} inválido; use: ${en.joinToString()}"
                }
                "integer" -> if (v !is Int && v !is Long) return "${p.name} deve ser inteiro"
                "boolean" -> if (v !is Boolean) return "${p.name} deve ser booleano"
                "array" -> {
                    if (v !is JSONArray) return "${p.name} deve ser lista"
                    if (v.length() > (p.max ?: 20)) return "${p.name} tem itens demais"
                    for (i in 0 until v.length()) if (v.get(i) !is String) return "${p.name} deve conter só texto"
                }
            }
        }
        val known = spec.params.map { it.name }.toSet()
        val it = args.keys()
        while (it.hasNext()) { val k = it.next(); if (k !in known) return "Parâmetro desconhecido: $k" }
        return null
    }
}
