package br.jarvis.plugin.core

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Voz do Jarvis (TextToSpeech do sistema, pt-BR). Inicializado sob demanda. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private val queue = ArrayDeque<Pair<String, () -> Unit>>()
    private val callbacks = HashMap<String, () -> Unit>()

    @Synchronized
    fun speak(ctx: Context, text: String, onDone: () -> Unit = {}) {
        if (text.isBlank()) { onDone(); return }
        if (tts == null) {
            queue.addLast(text.take(1500) to onDone)
            tts = TextToSpeech(ctx.applicationContext) { status ->
                synchronized(this) {
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale("pt", "BR")
                        tts?.setOnUtteranceProgressListener(listener)
                        ready = true
                        while (queue.isNotEmpty()) { val (t, cb) = queue.removeFirst(); speakNow(t, cb) }
                    } else {
                        val q = queue.toList(); queue.clear(); q.forEach { it.second() }
                    }
                }
            }
        } else if (!ready) {
            queue.addLast(text.take(1500) to onDone)
        } else {
            speakNow(text.take(1500), onDone)
        }
    }

    private fun speakNow(text: String, cb: () -> Unit) {
        val id = "u" + System.nanoTime()
        callbacks[id] = cb
        JarvisBus.emit("state", jo("state" to "speaking"))
        if (tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id) != TextToSpeech.SUCCESS) {
            callbacks.remove(id)?.invoke()
        }
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { finish(utteranceId) }
        @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { finish(utteranceId) }
    }

    private fun finish(id: String?) {
        val cb = synchronized(this) { callbacks.remove(id) }
        JarvisBus.emit("state", jo("state" to "idle"))
        cb?.invoke()
    }

    @Synchronized
    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null; ready = false; queue.clear(); callbacks.clear()
    }
}
