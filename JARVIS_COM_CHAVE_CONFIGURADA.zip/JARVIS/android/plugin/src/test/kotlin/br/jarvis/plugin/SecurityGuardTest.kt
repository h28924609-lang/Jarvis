package br.jarvis.plugin

import br.jarvis.plugin.controller.ToolSpecs
import br.jarvis.plugin.security.SecurityGuard
import br.jarvis.plugin.security.SecurityGuard.Sensitive
import br.jarvis.plugin.security.SecurityGuard.Verdict
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityGuardTest {
    @Test fun bloqueiaBancosPorPacote() {
        assertEquals(Verdict.BLOCK, SecurityGuard.checkApp("com.nu.production", null).verdict)
        assertEquals(Verdict.BLOCK, SecurityGuard.checkApp("br.com.qualquerbanco.app", null).verdict)
        assertEquals(Verdict.BLOCK, SecurityGuard.checkApp("com.samsung.android.spay", null).verdict)
    }
    @Test fun bloqueiaBancosPorNome() {
        assertEquals(Verdict.BLOCK, SecurityGuard.checkApp("com.x.y", "Nubank").verdict)
        assertEquals(Verdict.BLOCK, SecurityGuard.checkApp("com.x.y", "Banco do Brasil").verdict)
    }
    @Test fun permiteAppsComuns() {
        assertEquals(Verdict.ALLOW, SecurityGuard.checkApp("com.google.android.youtube", "YouTube").verdict)
        assertEquals(Verdict.ALLOW, SecurityGuard.checkApp("com.android.settings", "Configurações").verdict)
        assertEquals(Verdict.ALLOW, SecurityGuard.checkApp("com.whatsapp", "WhatsApp").verdict)
    }
    @Test fun bloqueiaPedidosFinanceiros() {
        assertEquals(Verdict.BLOCK, SecurityGuard.checkUserRequest("abra o Nubank e veja meu saldo").verdict)
        assertEquals(Verdict.BLOCK, SecurityGuard.checkUserRequest("faça um pix para o João").verdict)
        assertEquals(Verdict.ALLOW, SecurityGuard.checkUserRequest("pesquise caminhões Mercedes 1113 no YouTube").verdict)
        assertEquals(Verdict.ALLOW, SecurityGuard.checkUserRequest("explique o que é um banco de dados").verdict)
    }
    @Test fun bloqueiaFluxoFinanceiroNaTela() {
        assertEquals(Verdict.BLOCK, SecurityGuard.checkScreenText("Chave Pix | Valor | Confirmar").verdict)
        assertEquals(Verdict.BLOCK, SecurityGuard.checkScreenText("Transferir  Saldo R$ 10").verdict)
        assertEquals(Verdict.ALLOW, SecurityGuard.checkScreenText("Bluetooth | Wi-Fi | Conexões").verdict)
    }
    @Test fun classificaAcoesSensiveis() {
        assertEquals(Sensitive.MENSAGEM, SecurityGuard.classifyTarget("Enviar", null))
        assertEquals(Sensitive.EXCLUSAO, SecurityGuard.classifyTarget("Excluir conversa", null))
        assertEquals(Sensitive.CADASTRO, SecurityGuard.classifyTarget("Inscrever-se", null))
        assertEquals(Sensitive.MENSAGEM, SecurityGuard.classifyTarget(null, "com.whatsapp:id/send"))
        assertNull(SecurityGuard.classifyTarget("Pesquisar", "search_button"))
    }
    @Test fun validaArgumentosDasFerramentas() {
        val tap = ToolSpecs.byName("tap_element")!!
        assertNull(ToolSpecs.validate(tap, JSONObject("{\"element_id\":3}")))
        assertNotNull(ToolSpecs.validate(tap, JSONObject("{}")))
        assertNotNull(ToolSpecs.validate(tap, JSONObject("{\"element_id\":3,\"x\":1}")))
        val scroll = ToolSpecs.byName("scroll_screen")!!
        assertNotNull(ToolSpecs.validate(scroll, JSONObject("{\"direction\":\"diagonal\"}")))
        assertTrue(ToolSpecs.all.none { it.name.contains("confirm") })
    }
}
