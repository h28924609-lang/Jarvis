@tool
extends EditorPlugin

var _export_plugin: JarvisAndroidExport

func _enter_tree() -> void:
	_export_plugin = JarvisAndroidExport.new()
	add_export_plugin(_export_plugin)

func _exit_tree() -> void:
	remove_export_plugin(_export_plugin)
	_export_plugin = null

class JarvisAndroidExport extends EditorExportPlugin:
	const PLUGIN_NAME := "JarvisPlugin"

	func _get_name() -> String:
		return PLUGIN_NAME

	func _supports_platform(platform: EditorExportPlatform) -> bool:
		return platform is EditorExportPlatformAndroid

	func _get_android_libraries(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
		if debug:
			return PackedStringArray(["res://addons/jarvis_plugin/bin/jarvis-plugin-debug.aar"])
		return PackedStringArray(["res://addons/jarvis_plugin/bin/jarvis-plugin-release.aar"])

	func _get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
		return PackedStringArray([
			"org.jetbrains.kotlin:kotlin-stdlib:1.9.22",
			"org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3",
		])
