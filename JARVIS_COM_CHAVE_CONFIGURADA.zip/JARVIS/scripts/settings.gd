extends Control
## Configurações: servidor seguro de IA, permissões (com a finalidade de cada uma) e bloqueios extras.

const T := preload("res://scripts/ui_theme.gd")

const ROWS := [
	{"key": "accessibility", "title": "Serviço de acessibilidade", "action": "accessibility",
	 "why": "Permite ler a estrutura da tela e tocar, digitar e rolar nos apps. É a base do controle universal. Você ativa manualmente em Ajustes > Acessibilidade > JARVIS."},
	{"key": "microphone", "title": "Microfone", "action": "mic",
	 "why": "Reconhecer a palavra “Jarvis” e seus comandos de voz. Um aviso permanente fica visível enquanto a escuta está ligada. Nada é gravado em arquivo."},
	{"key": "notifications", "title": "Notificações", "action": "notifications",
	 "why": "Mostrar o aviso obrigatório de microfone ativo (com botão para desligar) e pedidos de confirmação quando o app estiver em segundo plano."},
	{"key": "battery", "title": "Sem otimização de bateria (opcional)", "action": "battery",
	 "why": "Evita que o Android encerre a escuta em segundo plano. Aumenta o consumo de bateria."},
]

var url_edit: LineEdit
var token_edit: LineEdit
var status_label: Label
var perm_labels := {}
var speak_check: CheckButton
var block_edit: LineEdit

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg := ColorRect.new()
	bg.color = T.BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	add_child(margin)
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 12)
	margin.add_child(outer)
	var head := HBoxContainer.new()
	outer.add_child(head)
	var t := T.label("Configurações", 36, T.CYAN)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(t)
	var close := Button.new()
	close.text = "✕"
	T.style_button(close, T.BLUE, false, 30)
	close.pressed.connect(func(): visible = false)
	head.add_child(close)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 14)
	scroll.add_child(v)

	# --- servidor de IA
	v.add_child(T.label("SERVIDOR SEGURO DE IA", 22, T.DIM))
	v.add_child(T.label("A chave Gemini fica somente no seu servidor. O app guarda apenas a URL (HTTPS) e um token do app.", 21, T.DIM))
	url_edit = LineEdit.new()
	url_edit.placeholder_text = "https://seu-servidor.exemplo.com"
	url_edit.custom_minimum_size = Vector2(0, 76)
	T.style_edit(url_edit, 24)
	v.add_child(url_edit)
	token_edit = LineEdit.new()
	token_edit.placeholder_text = "Token do app (deixe vazio para manter o atual)"
	token_edit.secret = true
	token_edit.custom_minimum_size = Vector2(0, 76)
	T.style_edit(token_edit, 24)
	v.add_child(token_edit)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	v.add_child(row)
	var save := Button.new()
	save.text = "Salvar e testar"
	save.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	save.custom_minimum_size = Vector2(0, 76)
	T.style_button(save, T.OK, true, 24)
	save.pressed.connect(func():
		Bridge.save_server(url_edit.text.strip_edges(), token_edit.text.strip_edges())
		token_edit.clear()
		status_label.text = "Testando conexão…"
		Bridge.test_connection())
	row.add_child(save)
	status_label = T.label("", 21, T.DIM)
	v.add_child(status_label)
	Bridge.ai_status.connect(func(ok, text):
		status_label.text = text
		status_label.add_theme_color_override("font_color", T.OK if ok else T.ERR))

	# --- permissões
	v.add_child(T.label("PERMISSÕES (concedidas manualmente por você)", 22, T.DIM))
	for r in ROWS:
		var p := PanelContainer.new()
		p.add_theme_stylebox_override("panel", T.box(Color(T.BLUE, 0.06), Color(T.BLUE, 0.4), 14, 2, 16))
		var pv := VBoxContainer.new()
		p.add_child(pv)
		var lab := T.label("", 26, T.TEXT)
		pv.add_child(lab)
		perm_labels[r["key"]] = lab
		pv.add_child(T.label(r["why"], 20, T.DIM))
		var b := Button.new()
		b.text = "Abrir / conceder"
		b.custom_minimum_size = Vector2(0, 66)
		T.style_button(b, T.BLUE, false, 22)
		var act: String = r["action"]
		b.pressed.connect(func(): _do(act))
		pv.add_child(b)
		v.add_child(p)
	var restricted := Button.new()
	restricted.text = "Android 13+: liberar “configurações restritas”"
	restricted.custom_minimum_size = Vector2(0, 70)
	T.style_button(restricted, T.WARN, false, 22)
	restricted.pressed.connect(func(): Bridge.open_app_details())
	v.add_child(restricted)
	v.add_child(T.label("Se a acessibilidade aparecer acinzentada: abra Informações do app > menu ⋮ > “Permitir configurações restritas”, depois volte e ative o serviço.", 20, T.DIM))

	# --- preferências e bloqueios
	v.add_child(T.label("PREFERÊNCIAS", 22, T.DIM))
	speak_check = CheckButton.new()
	speak_check.text = "Falar as respostas (comandos por voz)"
	speak_check.add_theme_font_size_override("font_size", 24)
	speak_check.add_theme_color_override("font_color", T.TEXT)
	speak_check.toggled.connect(func(on): Bridge.set_speak(on))
	v.add_child(speak_check)
	v.add_child(T.label("BLOQUEIO EXTRA DE APLICATIVOS", 22, T.DIM))
	v.add_child(T.label("Apps bancários e financeiros já são bloqueados sempre. Aqui você só ACRESCENTA outros pacotes (ex.: com.exemplo.app). A lista padrão não pode ser reduzida.", 20, T.DIM))
	block_edit = LineEdit.new()
	block_edit.placeholder_text = "pacote.do.app"
	block_edit.custom_minimum_size = Vector2(0, 76)
	T.style_edit(block_edit, 24)
	v.add_child(block_edit)
	var addb := Button.new()
	addb.text = "Bloquear este app"
	addb.custom_minimum_size = Vector2(0, 70)
	T.style_button(addb, T.ERR, false, 22)
	addb.pressed.connect(func():
		var p := block_edit.text.strip_edges()
		if p != "":
			Bridge.add_blocked_package(p)
			block_edit.clear())
	v.add_child(addb)
	Bridge.permissions_changed.connect(func(_s): refresh())

func _do(action: String) -> void:
	match action:
		"accessibility": Bridge.open_accessibility()
		"mic": Bridge.request_mic()
		"notifications": Bridge.request_notifications()
		"battery": Bridge.open_battery()

func refresh() -> void:
	if url_edit and Bridge.available:
		var cfg = JSON.parse_string(Bridge.plugin.getConfig())
		if cfg is Dictionary:
			url_edit.text = str(cfg.get("server_url", ""))
			speak_check.set_pressed_no_signal(bool(cfg.get("speak", true)))
	for r in ROWS:
		var ok: bool = bool(Bridge.permissions.get(r["key"], false))
		var lab: Label = perm_labels.get(r["key"])
		if lab:
			lab.text = ("✓ " if ok else "✗ ") + r["title"]
			lab.add_theme_color_override("font_color", T.OK if ok else T.WARN)
