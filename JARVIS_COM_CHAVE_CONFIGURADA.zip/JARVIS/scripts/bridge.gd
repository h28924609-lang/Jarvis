extends Node
## Ponte (autoload) entre a interface Godot e o plugin Kotlin "JarvisPlugin".
## Fora do Android (editor/desktop) NÃO simula nada: apenas informa que o plugin está ausente.

signal state_changed(state: String)
signal message_added(role: String, text: String)
signal task_started(id: String, title: String)
signal task_title(id: String, title: String)
signal task_plan(id: String, steps: Array)
signal task_step(id: String, index: int, status: String, note: String)
signal task_log(id: String, text: String, ok: bool, running: bool, detail: String)
signal task_finished(id: String, success: bool, summary: String)
signal confirm_request(id: String, title: String, description: String)
signal confirm_closed(id: String)
signal ai_status(connected: bool, text: String)
signal listening_changed(active: bool)
signal audio_level(level: float)
signal permissions_changed(status: Dictionary)

const PLUGIN_NAME := "JarvisPlugin"

var plugin: Object = null
var available := false
var permissions: Dictionary = {}
var config: Dictionary = {}

func _ready() -> void:
	if Engine.has_singleton(PLUGIN_NAME):
		plugin = Engine.get_singleton(PLUGIN_NAME)
		plugin.connect("jarvis_event", Callable(self, "_on_plugin_event"))
		available = true
		var info = JSON.parse_string(plugin.jarvisInit())
		if info is Dictionary:
			permissions = info.get("permissions", {})
			config = info.get("config", {})

## Chamado pela cena principal depois de conectar seus sinais (descarrega eventos em buffer).
func start() -> void:
	if available:
		plugin.jarvisAttach()
	else:
		message_added.emit("system", "Plugin Android indisponível: você está fora do Android. A interface funciona, mas nenhuma ação é executada.")

func _on_plugin_event(event_name: String, payload_json: String) -> void:
	var p = JSON.parse_string(payload_json)
	if not (p is Dictionary):
		p = {}
	match event_name:
		"state": state_changed.emit(str(p.get("state", "idle")))
		"message": message_added.emit(str(p.get("role", "assistant")), str(p.get("text", "")))
		"task_started": task_started.emit(str(p.get("id", "")), str(p.get("title", "")))
		"task_title": task_title.emit(str(p.get("id", "")), str(p.get("title", "")))
		"task_plan": task_plan.emit(str(p.get("id", "")), p.get("steps", []))
		"task_step": task_step.emit(str(p.get("id", "")), int(p.get("index", 0)), str(p.get("status", "")), str(p.get("note", "")))
		"task_log": task_log.emit(str(p.get("id", "")), str(p.get("text", "")), bool(p.get("ok", true)), bool(p.get("running", false)), str(p.get("detail", "")))
		"task_finished": task_finished.emit(str(p.get("id", "")), bool(p.get("success", false)), str(p.get("summary", "")))
		"confirm_request": confirm_request.emit(str(p.get("id", "")), str(p.get("title", "")), str(p.get("description", "")))
		"confirm_closed": confirm_closed.emit(str(p.get("id", "")))
		"ai_status": ai_status.emit(bool(p.get("connected", false)), str(p.get("text", "")))
		"listening_changed": listening_changed.emit(bool(p.get("active", false)))
		"audio_level": audio_level.emit(float(p.get("level", 0.0)))
		"permissions_changed":
			for k in p.keys():
				permissions[k] = p[k]
			permissions_changed.emit(permissions)

func _need_plugin() -> bool:
	if not available:
		message_added.emit("system", "Disponível apenas no Android com o plugin instalado.")
	return available

# ---- comandos ----
func send_command(text: String) -> void:
	if _need_plugin(): plugin.sendCommand(text)
func listen_once() -> void:
	if _need_plugin(): plugin.listenOnce()
func set_wake(on: bool) -> void:
	if not _need_plugin(): return
	if on: plugin.startWakeListening()
	else: plugin.stopWakeListening()
func confirm(id: String, approved: bool) -> void:
	if available: plugin.confirmAction(id, approved)
func cancel_task() -> void:
	if available: plugin.cancelTask()

# ---- configuração e permissões ----
func save_server(url: String, token: String) -> void:
	if _need_plugin(): plugin.setServer(url, token)
func test_connection() -> void:
	if _need_plugin(): plugin.testConnection()
func set_speak(on: bool) -> void:
	if available: plugin.setSpeakReplies(on)
func add_blocked_package(pkg: String) -> void:
	if available: plugin.addBlockedPackage(pkg)
func open_accessibility() -> void:
	if _need_plugin(): plugin.openAccessibilitySettings()
func open_app_details() -> void:
	if _need_plugin(): plugin.openAppDetails()
func open_battery() -> void:
	if _need_plugin(): plugin.openBatterySettings()
func request_mic() -> void:
	if _need_plugin(): plugin.requestMicPermission()
func request_notifications() -> void:
	if _need_plugin(): plugin.requestNotificationPermission()
