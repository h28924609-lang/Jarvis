extends Control
## Círculo central luminoso com anéis de onda. O desenho muda conforme o estado.

const T := preload("res://scripts/ui_theme.gd")

var state := "idle"
var target_level := 0.0
var _level := 0.0
var _t := 0.0

func set_state(s: String) -> void:
	state = s

func set_level(v: float) -> void:
	target_level = clampf(v, 0.0, 1.0)

func _process(delta: float) -> void:
	_t += delta
	_level = lerpf(_level, target_level, 0.25)
	target_level = maxf(0.0, target_level - delta * 1.5)
	queue_redraw()

func _accent() -> Color:
	match state:
		"executing": return T.CYAN
		"error": return T.ERR
		"speaking": return Color("8be9ff")
		_: return T.BLUE

func _draw() -> void:
	var c := size / 2.0
	var base := minf(size.x, size.y) * 0.24
	var col := _accent()
	var amp := 0.25
	var speed := 1.2
	match state:
		"listening": amp = 0.55 + _level * 2.2; speed = 3.0
		"processing": amp = 0.35; speed = 5.0
		"executing": amp = 0.45; speed = 3.5
		"speaking": amp = 0.6 + 0.4 * absf(sin(_t * 6.0)); speed = 4.0
		"error": amp = 0.15; speed = 0.8
	# halo
	for i in range(9):
		draw_circle(c, base * (1.0 + i * 0.13), Color(col, 0.030 * float(9 - i) / 9.0))
	# núcleo
	draw_circle(c, base * 0.84, Color("04101f"))
	draw_arc(c, base, 0.0, TAU, 96, col, 3.0, true)
	draw_arc(c, base * 0.88, 0.0, TAU, 96, Color(col, 0.35), 1.5, true)
	# anel de ondas sonoras
	var pts := PackedVector2Array()
	var n := 120
	var wa := base * 0.07 * amp
	for i in range(n + 1):
		var a := TAU * float(i) / float(n)
		var r := base * 1.2 + sin(a * 7.0 + _t * speed) * wa + sin(a * 3.0 - _t * speed * 0.6) * wa * 0.7
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	draw_polyline(pts, Color(col, 0.85), 2.0, true)
	# segundo anel mais fraco
	var pts2 := PackedVector2Array()
	for i in range(n + 1):
		var a2 := TAU * float(i) / float(n)
		var r2 := base * 1.38 + sin(a2 * 5.0 - _t * speed * 0.8) * wa * 1.3
		pts2.append(c + Vector2(cos(a2), sin(a2)) * r2)
	draw_polyline(pts2, Color(col, 0.28), 1.5, true)
	# arcos giratórios (processando/executando)
	if state == "processing" or state == "executing":
		var rot := _t * (4.0 if state == "processing" else 2.5)
		for k in range(3):
			var s := rot + k * TAU / 3.0
			draw_arc(c, base * 1.55, s, s + 0.9, 24, col, 4.0, true)
	# forma de onda central
	if state == "listening" or state == "speaking":
		var w := base * 1.1
		var prev := Vector2(-w, 0)
		for i in range(1, 41):
			var x := -w + (2.0 * w) * float(i) / 40.0
			var env := sin(PI * float(i) / 40.0)
			var y := sin(x * 0.09 + _t * 9.0) * base * 0.28 * env * (0.3 + _level * 2.0 if state == "listening" else 0.8)
			draw_line(c + prev, c + Vector2(x, y), T.CYAN, 2.5, true)
			prev = Vector2(x, y)
	elif state == "idle":
		draw_circle(c, base * 0.10 * (1.0 + 0.25 * sin(_t * 2.0)), Color(col, 0.9))
