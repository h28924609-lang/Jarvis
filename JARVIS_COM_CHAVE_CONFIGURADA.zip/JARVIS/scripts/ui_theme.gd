extends RefCounted
## Paleta e estilos compartilhados (tema holográfico azul elétrico).

const BG := Color("03060d")
const PANEL := Color("08121f")
const BLUE := Color("1ea7ff")
const CYAN := Color("5ff3ff")
const TEXT := Color("d6ecff")
const DIM := Color("6a88a8")
const OK := Color("37e08f")
const ERR := Color("ff5470")
const WARN := Color("ffc857")

static func box(bg: Color, border: Color = Color(0, 0, 0, 0), radius: int = 16, border_w: int = 0, pad: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad
	s.content_margin_bottom = pad
	return s

static func style_button(b: Button, accent: Color = BLUE, filled: bool = false, font_size: int = 26) -> void:
	var base := Color(accent, 0.20) if filled else Color(accent, 0.05)
	b.add_theme_stylebox_override("normal", box(base, accent, 14, 2, 14))
	b.add_theme_stylebox_override("hover", box(Color(accent, 0.30), accent, 14, 2, 14))
	b.add_theme_stylebox_override("pressed", box(Color(accent, 0.45), CYAN, 14, 2, 14))
	b.add_theme_stylebox_override("disabled", box(Color(DIM, 0.1), DIM, 14, 1, 14))
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_font_size_override("font_size", font_size)

static func label(text: String, size: int = 26, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

static func style_edit(e: LineEdit, size: int = 26) -> void:
	e.add_theme_stylebox_override("normal", box(Color(BLUE, 0.07), Color(BLUE, 0.6), 14, 2, 14))
	e.add_theme_stylebox_override("focus", box(Color(BLUE, 0.12), CYAN, 14, 2, 14))
	e.add_theme_color_override("font_color", TEXT)
	e.add_theme_color_override("font_placeholder_color", DIM)
	e.add_theme_color_override("caret_color", CYAN)
	e.add_theme_font_size_override("font_size", size)
