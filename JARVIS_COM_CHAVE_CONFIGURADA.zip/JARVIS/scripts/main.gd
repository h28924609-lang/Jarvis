extends Control
## Tela principal: orb, estado, conversa, tarefas, histórico, entrada e confirmações.

const T := preload("res://scripts/ui_theme.gd")
const OrbScript := preload("res://scripts/orb.gd")
const TaskPanelScene := preload("res://scenes/TaskPanel.tscn")
const SettingsScene := preload("res://scenes/Settings.tscn")
const HISTORY_PATH := "user://history.json"
const MAX_HISTORY := 100

const STATE_TEXT := {
	"idle": "EM ESPERA", "listening": "OUVINDO…", "processing": "PENSANDO…",
	"executing": "EXECUTANDO…", "speaking": "FALANDO…", "error": "ATENÇÃO",
}

var orb: Control
var state_label: Label
var conn_dot: Label
var conn_label: Label
var views := {}
var convo_box: VBoxContainer
var convo_scroll: ScrollContainer
var history_box: VBoxContainer
var input: LineEdit
var wake_check: CheckButton
var confirm_overlay: Control
var confirm_title: Label
var confirm_text: Label
var confirm_id := ""
var settings_panel: Control
var history: Array = []
var _last_user_text := ""

func _ready() -> void:
	Engine.max_fps = 30
	_build_ui()
	_load_history()
	Bridge.state_changed.connect(_on_state)
	Bridge.message_added.connect(_on_message)
	Bridge.ai_status.connect(_on_ai_status)
	Bridge.listening_changed.connect(func(a): wake_check.set_pressed_no_signal(a))
	Bridge.audio_level.connect(func(v): orb.set_level(v))
	Bridge.task_finished.connect(_on_task_finished)
	Bridge.confirm_request.connect(_on_confirm_request)
	Bridge.confirm_closed.connect(func(id): if id == confirm_id: confirm_overlay.visible = false)
	_set_conn(false, "IA não configurada" if not Bridge.permissions.get("ai_configured", false) else "IA configurada")
	Bridge.start()
	if Bridge.available and Bridge.config.get("wake", false):
		wake_check.set_pressed_no_signal(true)

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED: if orb: orb.set_process(false)
		NOTIFICATION_APPLICATION_RESUMED: if orb: orb.set_process(true)
		NOTIFICATION_WM_GO_BACK_REQUEST:
			if confirm_overlay and confirm_overlay.visible: return
			if settings_panel and settings_panel.visible: settings_panel.visible = false
			else: get_tree().quit()

# ------------------------------------------------------------------ UI
func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = T.BG
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 24)
	add_child(margin)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 12)
	margin.add_child(col)

	# cabeçalho
	var head := HBoxContainer.new()
	col.add_child(head)
	var title := T.label("J A R V I S", 40, T.CYAN)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	conn_dot = T.label("●", 26, T.ERR)
	head.add_child(conn_dot)
	conn_label = T.label("", 20, T.DIM)
	head.add_child(conn_label)
	var gear := Button.new()
	gear.text = "⚙"
	T.style_button(gear, T.BLUE, false, 30)
	gear.pressed.connect(func(): settings_panel.visible = true; settings_panel.refresh())
	head.add_child(gear)

	# orb
	orb = Control.new()
	orb.set_script(OrbScript)
	orb.custom_minimum_size = Vector2(0, 380)
	col.add_child(orb)
	state_label = T.label(STATE_TEXT["idle"], 28, T.BLUE)
	state_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(state_label)

	# abas
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 10)
	col.add_child(tabs)
	var group := ButtonGroup.new()
	var content := Control.new()
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(content)
	for entry in [["conversa", "CONVERSA"], ["tarefas", "TAREFAS"], ["historico", "HISTÓRICO"]]:
		var b := Button.new()
		b.text = entry[1]
		b.toggle_mode = true
		b.button_group = group
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		T.style_button(b, T.BLUE, false, 22)
		b.add_theme_stylebox_override("pressed", T.box(Color(T.BLUE, 0.35), T.CYAN, 14, 2, 14))
		var key: String = entry[0]
		b.pressed.connect(func(): _show_view(key))
		tabs.add_child(b)
		if key == "conversa": b.button_pressed = true

	# conversa
	convo_scroll = ScrollContainer.new()
	convo_scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	convo_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(convo_scroll)
	convo_box = VBoxContainer.new()
	convo_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	convo_box.add_theme_constant_override("separation", 10)
	convo_scroll.add_child(convo_box)
	views["conversa"] = convo_scroll

	# tarefas
	var tp := TaskPanelScene.instantiate()
	content.add_child(tp)
	views["tarefas"] = tp

	# histórico
	var hs := ScrollContainer.new()
	hs.set_anchors_preset(Control.PRESET_FULL_RECT)
	hs.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(hs)
	history_box = VBoxContainer.new()
	history_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	history_box.add_theme_constant_override("separation", 10)
	hs.add_child(history_box)
	views["historico"] = hs
	_show_view("conversa")

	# escuta por palavra de ativação
	wake_check = CheckButton.new()
	wake_check.text = "Escuta por “Jarvis” (microfone ativo)"
	wake_check.add_theme_font_size_override("font_size", 22)
	wake_check.add_theme_color_override("font_color", T.DIM)
	wake_check.toggled.connect(func(on): Bridge.set_wake(on))
	col.add_child(wake_check)

	# entrada
	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 10)
	col.add_child(bar)
	input = LineEdit.new()
	input.placeholder_text = "Peça algo ao Jarvis…"
	input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	input.custom_minimum_size = Vector2(0, 84)
	T.style_edit(input, 26)
	input.text_submitted.connect(func(_t): _on_send())
	bar.add_child(input)
	var send := Button.new()
	send.text = "➤"
	send.custom_minimum_size = Vector2(84, 84)
	T.style_button(send, T.BLUE, true, 32)
	send.pressed.connect(_on_send)
	bar.add_child(send)
	var mic := Button.new()
	mic.text = "🎤"
	mic.custom_minimum_size = Vector2(96, 84)
	T.style_button(mic, T.CYAN, true, 34)
	mic.pressed.connect(func(): Bridge.listen_once())
	bar.add_child(mic)

	_build_confirm()
	settings_panel = SettingsScene.instantiate()
	settings_panel.visible = false
	add_child(settings_panel)

func _build_confirm() -> void:
	confirm_overlay = Control.new()
	confirm_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	confirm_overlay.visible = false
	confirm_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(confirm_overlay)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.78)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	confirm_overlay.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	confirm_overlay.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(620, 0)
	panel.add_theme_stylebox_override("panel", T.box(T.PANEL, T.WARN, 20, 3, 28))
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 18)
	panel.add_child(v)
	confirm_title = T.label("Confirmar ação", 34, T.WARN)
	v.add_child(confirm_title)
	confirm_text = T.label("", 26, T.TEXT)
	v.add_child(confirm_text)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	v.add_child(row)
	var no := Button.new()
	no.text = "Cancelar"
	no.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	no.custom_minimum_size = Vector2(0, 84)
	T.style_button(no, T.ERR, false, 28)
	no.pressed.connect(func(): _answer(false))
	row.add_child(no)
	var yes := Button.new()
	yes.text = "Confirmar"
	yes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	yes.custom_minimum_size = Vector2(0, 84)
	T.style_button(yes, T.OK, true, 28)
	yes.pressed.connect(func(): _answer(true))
	row.add_child(yes)

# ------------------------------------------------------------------ lógica
func _show_view(key: String) -> void:
	for k in views.keys():
		views[k].visible = (k == key)

func _on_send() -> void:
	var t := input.text.strip_edges()
	if t.is_empty(): return
	input.clear()
	Bridge.send_command(t)

func _on_state(s: String) -> void:
	orb.set_state(s)
	state_label.text = STATE_TEXT.get(s, s.to_upper())
	state_label.add_theme_color_override("font_color", T.ERR if s == "error" else (T.CYAN if s == "executing" else T.BLUE))

func _on_ai_status(connected: bool, text: String) -> void:
	_set_conn(connected, text)

func _set_conn(ok: bool, text: String) -> void:
	conn_dot.add_theme_color_override("font_color", T.OK if ok else T.ERR)
	conn_label.text = " " + text.left(26)

func _on_message(role: String, text: String) -> void:
	if role == "user": _last_user_text = text
	convo_box.add_child(_bubble(role, text))
	while convo_box.get_child_count() > 80:
		convo_box.get_child(0).queue_free()
		break
	_scroll_bottom()

func _bubble(role: String, text: String) -> Control:
	var accent := T.BLUE
	var who := "JARVIS"
	if role == "user": accent = T.CYAN; who = "VOCÊ"
	elif role == "system": accent = T.DIM; who = "SISTEMA"
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", T.box(Color(accent, 0.08), Color(accent, 0.55), 16, 2, 16))
	var v := VBoxContainer.new()
	p.add_child(v)
	v.add_child(T.label(who, 18, accent))
	v.add_child(T.label(text, 26, T.TEXT))
	return p

func _scroll_bottom() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	convo_scroll.scroll_vertical = int(convo_scroll.get_v_scroll_bar().max_value)

func _on_confirm_request(id: String, title: String, description: String) -> void:
	confirm_id = id
	confirm_title.text = title
	confirm_text.text = description
	confirm_overlay.visible = true
	_show_view("conversa")

func _answer(ok: bool) -> void:
	confirm_overlay.visible = false
	Bridge.confirm(confirm_id, ok)

# ------------------------------------------------------------------ histórico
func _on_task_finished(_id: String, success: bool, summary: String) -> void:
	history.push_front({"ts": Time.get_datetime_string_from_system(false, true), "command": _last_user_text, "success": success, "summary": summary})
	if history.size() > MAX_HISTORY: history.resize(MAX_HISTORY)
	_save_history()
	_render_history()

func _load_history() -> void:
	if FileAccess.file_exists(HISTORY_PATH):
		var f := FileAccess.open(HISTORY_PATH, FileAccess.READ)
		var data = JSON.parse_string(f.get_as_text())
		if data is Array: history = data
	_render_history()

func _save_history() -> void:
	var f := FileAccess.open(HISTORY_PATH, FileAccess.WRITE)
	if f: f.store_string(JSON.stringify(history))

func _render_history() -> void:
	for c in history_box.get_children(): c.queue_free()
	if history.is_empty():
		history_box.add_child(T.label("Sem tarefas registradas ainda.", 26, T.DIM))
		return
	var clear := Button.new()
	clear.text = "Limpar histórico"
	T.style_button(clear, T.ERR, false, 22)
	clear.pressed.connect(func(): history.clear(); _save_history(); _render_history())
	history_box.add_child(clear)
	for h in history:
		var p := PanelContainer.new()
		var ok: bool = h.get("success", false)
		p.add_theme_stylebox_override("panel", T.box(Color(T.OK if ok else T.ERR, 0.07), Color(T.OK if ok else T.ERR, 0.5), 14, 2, 14))
		var v := VBoxContainer.new()
		p.add_child(v)
		v.add_child(T.label("%s  %s" % ["✓" if ok else "✗", str(h.get("ts", ""))], 20, T.DIM))
		v.add_child(T.label(str(h.get("command", "")), 24, T.CYAN))
		v.add_child(T.label(str(h.get("summary", "")), 22, T.TEXT))
		history_box.add_child(p)
