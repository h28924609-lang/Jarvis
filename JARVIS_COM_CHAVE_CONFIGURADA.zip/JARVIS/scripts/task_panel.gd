extends Control
## Acompanhamento de tarefas: plano em etapas com status e registro de ações executadas.

const T := preload("res://scripts/ui_theme.gd")

var _title: Label
var _steps_box: VBoxContainer
var _log_box: VBoxContainer
var _cancel: Button
var _empty: Label
var _step_labels: Array[Label] = []
var _step_texts: Array[String] = []
var _current_id := ""

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var scroll := ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override("separation", 14)
	scroll.add_child(root)
	_empty = T.label("Nenhuma tarefa em execução.\nPeça algo ao Jarvis para acompanhar as etapas aqui.", 26, T.DIM)
	root.add_child(_empty)
	_title = T.label("", 30, T.CYAN)
	root.add_child(_title)
	_steps_box = VBoxContainer.new()
	_steps_box.add_theme_constant_override("separation", 8)
	root.add_child(_steps_box)
	root.add_child(T.label("AÇÕES EXECUTADAS", 22, T.DIM))
	_log_box = VBoxContainer.new()
	_log_box.add_theme_constant_override("separation", 4)
	root.add_child(_log_box)
	_cancel = Button.new()
	_cancel.text = "Cancelar tarefa"
	T.style_button(_cancel, T.ERR, false, 26)
	_cancel.pressed.connect(func(): Bridge.cancel_task())
	_cancel.visible = false
	root.add_child(_cancel)
	Bridge.task_started.connect(_on_started)
	Bridge.task_title.connect(func(id, t): if id == _current_id: _title.text = "TAREFA: " + t)
	Bridge.task_plan.connect(_on_plan)
	Bridge.task_step.connect(_on_step)
	Bridge.task_log.connect(_on_log)
	Bridge.task_finished.connect(_on_finished)

func _clear() -> void:
	for c in _steps_box.get_children(): c.queue_free()
	for c in _log_box.get_children(): c.queue_free()
	_step_labels.clear()
	_step_texts.clear()

func _on_started(id: String, title: String) -> void:
	_current_id = id
	_clear()
	_empty.visible = false
	_title.text = "TAREFA: " + title
	_cancel.visible = true

func _on_plan(id: String, steps: Array) -> void:
	if id != _current_id: return
	for c in _steps_box.get_children(): c.queue_free()
	_step_labels.clear()
	_step_texts.clear()
	for s in steps:
		var l := T.label("", 26, T.DIM)
		_steps_box.add_child(l)
		_step_labels.append(l)
		_step_texts.append(str(s))
	for i in range(_step_labels.size()):
		_set_label(i, "pending")

func _set_label(i: int, status: String, note: String = "") -> void:
	if i < 0 or i >= _step_labels.size(): return
	var tag := "[Pendente]"
	var col := T.DIM
	match status:
		"running": tag = "[Em andamento]"; col = T.BLUE
		"done": tag = "[Concluído]"; col = T.OK
		"failed": tag = "[Falhou]"; col = T.ERR
	var txt := "%s %s" % [tag, _step_texts[i]]
	if note != "": txt += " — " + note
	_step_labels[i].text = txt
	_step_labels[i].add_theme_color_override("font_color", col)

func _on_step(id: String, index: int, status: String, note: String) -> void:
	if id == _current_id: _set_label(index, status, note)

var _last_log: Label = null
var _last_log_text := ""

func _on_log(id: String, text: String, ok: bool, running: bool, detail: String) -> void:
	if id != _current_id: return
	if running:
		_last_log = T.label("… " + text, 22, T.BLUE)
		_last_log_text = text
		_log_box.add_child(_last_log)
	elif _last_log != null and _last_log_text == text:
		_last_log.text = ("✓ " if ok else "✗ ") + text + ("" if ok or detail == "" else " — " + detail)
		_last_log.add_theme_color_override("font_color", T.OK if ok else T.ERR)
		_last_log = null

func _on_finished(id: String, success: bool, summary: String) -> void:
	if id != _current_id: return
	_cancel.visible = false
	var l := T.label(("Concluída: " if success else "Encerrada: ") + summary, 24, T.OK if success else T.ERR)
	_log_box.add_child(l)
	if not success:
		for i in range(_step_labels.size()):
			if _step_labels[i].text.begins_with("[Em andamento]"): _set_label(i, "failed")
