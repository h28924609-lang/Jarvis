# Segurança
Camadas aplicadas **no código**, independentes do que a IA pedir:

1. **Triagem do pedido** (`SecurityGuard.checkUserRequest`): pedidos com bancos/Pix/boleto/saldo etc. são recusados antes de chamar a IA.
2. **Bloqueio de app** antes de abrir e antes de cada ação (`checkApp`): lista de pacotes, heurística por nome de pacote e por rótulo, mais bloqueios extras do usuário (só crescem).
3. **Bloqueio de fluxo financeiro dentro de qualquer app** (`checkScreenText`): termos fortes (chave Pix, boleto, CVV, extrato…) ou 2+ termos fracos na tela. Ao detectar: vai para a tela inicial e aborta a tarefa.
4. **Vigia de eventos**: se um app bancário surgir durante uma tarefa, aborta mesmo sem ação da IA.
5. **Confirmação** (`ConfirmationGate`) para enviar, publicar, excluir, comprar, cadastrar/inscrever, compartilhar, gravar e ligar. Mostra app, elemento e o rascunho do texto. Só a tela/notificação confirma; a IA não tem ferramenta para isso. Timeout de 60 s = recusa.
6. **Catálogo fechado de ferramentas** com validação de schema; o servidor também filtra a lista.
7. **Campos de senha**: nunca lidos nem preenchidos. Telas protegidas: a captura simplesmente falha.
8. **Anti-alucinação**: `finish_task(success=true)` exige texto visível na tela como evidência.
9. **Anti-loop**: máx. 30 passos, 5 falhas seguidas, ações repetidas abortam; teto de 5 min.
10. **Conteúdo da tela = dado não confiável** (defesa contra prompt injection, no prompt e no resultado das ferramentas).
11. **Chave da OpenAI só no servidor**; app usa token próprio e HTTPS obrigatório.

Limitações honestas: a lista de bancos é inicial e heurística (pode ter falsos positivos, como apps com “wallet”/“carteira”, e falsos negativos); nomes de pacote não foram todos verificados. Falsos positivos são o lado seguro. Revise a lista para o seu aparelho. O Jarvis recusa operar telas de permissão/instalação do Android e o próprio app.
