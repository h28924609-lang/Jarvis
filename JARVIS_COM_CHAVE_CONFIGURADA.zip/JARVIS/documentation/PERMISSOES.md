# Manual de permissões
Todas são concedidas **manualmente por você**; o app explica cada uma em ⚙ Configurações.

| Permissão | Para quê | Como conceder |
|---|---|---|
| **Serviço de acessibilidade** | Ler a estrutura da tela e executar toques, digitação, rolagem e captura de tela autorizada. Base do controle universal. | ⚙ > Abrir / conceder > Ajustes > Acessibilidade > JARVIS > Ativar |
| **Configurações restritas (Android 13+)** | Apps instalados fora da loja (APK) têm a acessibilidade bloqueada até você liberar. | Informações do app > ⋮ > *Permitir configurações restritas* |
| **Microfone (RECORD_AUDIO)** | Reconhecer “Jarvis” e comandos de voz. Nada é gravado em arquivo. | Diálogo do Android |
| **Notificações (POST_NOTIFICATIONS)** | Aviso persistente de microfone ativo (botão Desligar) e confirmações em segundo plano. | Diálogo do Android |
| **Serviço em primeiro plano (microfone)** | Manter a escuta com a tela apagada, sempre com notificação visível. | Automático ao ligar a escuta |
| **WAKE_LOCK** | Manter a CPU ativa só enquanto a escuta está ligada. | Automático |
| **Internet** | Falar apenas com o seu servidor HTTPS. | Automático |
| **Ignorar otimização de bateria** (opcional) | Evitar que o Android encerre a escuta. Aumenta consumo. | ⚙ > Sem otimização de bateria |

Limites do Android: a escuta não funciona com o aparelho desligado; no bloqueio de tela o sistema pode restringir microfone e impedir toques em telas seguras (PIN/biometria nunca são contornados). Só ligue a escuta com o app visível (o Android 14 restringe iniciar serviço de microfone em segundo plano). Distribuição na Google Play é inadequada: a política de acessibilidade restringe serviços que não sejam ferramentas de acessibilidade. Use instalação direta do APK.
