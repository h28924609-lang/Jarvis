# JARVIS – assistente de controle universal do Android

App Android único (APK) com **Godot 4.3** (interface), **plugin Kotlin** (acessibilidade, voz, segurança) e **OpenAI API** via **servidor intermediário** (a chave nunca vai no APK).

Estado desta entrega: **código-fonte completo, NÃO compilado nem testado em aparelho** (veja `TESTES.md`). O APK precisa ser gerado na sua máquina.

Leia nesta ordem: `INSTALACAO.md` → `PERMISSOES.md` → `SEGURANCA.md` → `ARQUITETURA.md` → `TESTES.md`.

## Estrutura
```
JARVIS/
  project.godot, export_presets.cfg
  scenes/        Main, TaskPanel, Settings
  scripts/       main, orb (círculo luminoso), task_panel, settings, bridge (autoload), ui_theme
  assets/        icon.svg
  addons/jarvis_plugin/   plugin de exportação do Godot (inclui o AAR Kotlin)
  android/plugin/         projeto Gradle do plugin Kotlin
    src/main/kotlin/br/jarvis/plugin/
      accessibility/  AccessibilityService + leitor da árvore da tela
      controller/     AndroidController (executor), ToolSpecs (ferramentas), AppResolver
      security/       SecurityGuard (bloqueio bancário, sensíveis), ConfirmationGate
      automation/     AgentLoop (planejar-agir-verificar), TaskRun
      ai/             JarvisAI (cliente do servidor seguro)
      voice/          VoiceEngine (pt-BR), VoiceService (foreground)
      core/           JarvisCore, Bus, Config, Notifier, Speaker, ActionReceiver
  server/         proxy Node (OpenAI) + testes
  documentation/
```
As pastas ai/, voice/, accessibility/, controller/, security/, automation/ sugeridas existem como **pacotes** dentro do módulo Gradle (estrutura exigida pelo Kotlin/Gradle).
