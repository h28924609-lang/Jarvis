# Testes: o que foi e o que NÃO foi feito

Ambiente de desenvolvimento desta entrega: sem Godot, sem Android SDK/Gradle e sem rede. **Nada abaixo marcado “não executado” foi verificado.**

| # | Item | Status |
|---|---|---|
| 1 | Inicialização | Não executado |
| 2 | Interface (Godot) | Não executado (sintaxe: colchetes balanceados; cenas conferidas) |
| 3 | Comunicação Godot/Kotlin | Não executado |
| 4 | Pedido de permissões | Não executado |
| 5–7 | Palavra de ativação, pt-BR, tela apagada | Não executado (exige aparelho) |
| 8–12 | Identificar elementos, tocar, digitar, rolar, trocar de app | Não executado (exige aparelho) |
| 13 | Tarefas com várias etapas | Não executado |
| 14 | Tratamento de falhas | Não executado (lógica escrita; sem teste) |
| 15 | Bloqueio bancário | **Parcial**: regex de pedido, rótulo, pacote e tela testadas em Java (22 casos; 21 OK; o 1 falho foi `com.nu.production` no harness, que não incluía a lista explícita de pacotes presente no Kotlin). Testes JUnit escritos em `android/plugin/src/test`, **não executados**. |
| 16 | Confirmações | Não executado (lógica escrita) |
| 17 | Consumo de memória | Não executado |
| 18 | Exportação Android / compilação do plugin | **Não executado**: Kotlin e GDScript nunca foram compilados |
| – | Servidor intermediário | **Executado**: 6/6 testes (auth, repasse, ferramentas permitidas, validação, vazamento de erro, rate limit) com upstream falso |
| – | XML do manifest/recursos | Validados como XML bem formado |

Roteiro para você: `./gradlew testDebugUnitTest` (JUnit), `cd server && npm test`, depois no aparelho: (a) ativar acessibilidade; (b) “abra as configurações e encontre Bluetooth”; (c) YouTube com busca; (d) tentar “abra o Nubank” (deve recusar); (e) digitar uma mensagem e tocar em Enviar (deve pedir confirmação); (f) medir bateria com a escuta ligada por 1 h.
Esperar erros de compilação na primeira build (código não compilado).
