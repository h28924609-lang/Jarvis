# Instalação e build

## Requisitos
Godot 4.3 (com templates de exportação Android), Android Studio (SDK 34 + Build-Tools), JDK 17, Node 18+ (servidor).

## 1. Servidor intermediário
Veja `server/README.md`. Configure `GEMINI_API_KEY` e `JARVIS_APP_TOKENS` como variáveis de ambiente no servidor e publique com **HTTPS**. Para evitar qualquer cobrança, não habilite faturamento no projeto Google.

## 2. Compilar o plugin Kotlin
```bash
cd android/plugin
gradle wrapper            # gera o gradlew (ou abra a pasta no Android Studio)
./gradlew assembleDebug assembleRelease
```
Os AARs são copiados para `addons/jarvis_plugin/bin/` (`jarvis-plugin-debug.aar`, `jarvis-plugin-release.aar`).
A versão `org.godotengine:godot:4.3.0.stable` em `build.gradle.kts` deve ser a do seu Godot.
Se a compilação reclamar de `emitSignal` em `JarvisPlugin.kt`, ajuste só aquela linha à assinatura da sua godot-lib.

## 3. Exportar no Godot
1. Abra `project.godot`. Projeto > Ferramentas > Android > **Instalar modelo de compilação**.
2. Configurações do Projeto > Plugins: ative **Jarvis Android Plugin**.
3. Projeto > Exportar > Android: confirme *Use Gradle Build* ligado, arm64-v8a, pacote `br.jarvis.assistant`, e configure seu keystore.
4. Exportar APK (`build/jarvis.apk`) e instalar: `adb install build/jarvis.apk`.
(O `export_presets.cfg` foi escrito à mão; se o Godot estranhar algum campo, recrie o preset em Exportar mantendo as opções acima.)

## 4. Primeiro uso no Galaxy A16
Abra o app > ⚙ > informe a URL HTTPS do seu servidor + token do app > Salvar e testar. Depois conceda as permissões em `PERMISSOES.md`.
