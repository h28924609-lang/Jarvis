# Arquitetura
```
Godot (UI) --jarvis_event(nome, json)--> sinais do Bridge
   ^  chamadas @UsedByGodot (strings/JSON)
JarvisPlugin (Kotlin) -> JarvisCore -> AgentLoop -> JarvisAI --HTTPS--> servidor --> Gemini API (compatibilidade OpenAI)
                                          |
                                   AndroidController  -> SecurityGuard / ConfirmationGate
                                          |
                          JarvisAccessibilityService (ACTION_CLICK, ACTION_SET_TEXT, scroll, gestos, screenshot)
VoiceService (foreground) -> VoiceEngine (SpeechRecognizer pt-BR) -> JarvisCore.submitCommand
```
Ferramentas: get_current_app, inspect_screen, find_element, tap_element, type_text, scroll_screen, press_back, press_home, open_app, switch_app, wait_for_screen_change, read_accessible_text, capture_screen, tap_point (+ set_plan, report_progress, finish_task).

Ações são semânticas (ACTION_CLICK/ACTION_SET_TEXT/ACTION_SCROLL_*) por ID de elemento da última inspeção; gestos por coordenadas só como fallback ou via captura visual (coordenadas normalizadas 0–1000, independentes do tamanho de tela).

Bateria/memória: eventos de acessibilidade só incrementam um contador; a árvore é lida sob demanda; IA só roda durante tarefas; a UI limita 30 FPS e para de desenhar em pausa; wake lock só com escuta ligada.

Palavra de ativação: usa o SpeechRecognizer do sistema (pt-BR, preferindo offline) em sessões curtas procurando “Jarvis”. Não é um detector dedicado de palavra-chave: consome mais bateria e pode emitir bipe/falhar em alguns aparelhos. Por isso fica **desligada por padrão**. Alternativa recomendada para produção: motor on-device (ex.: Porcupine ou Vosk) atrás da mesma interface em `VoiceEngine`.
Limitações: `open_app` usa `startActivity` pelo serviço de acessibilidade; se o Android bloquear a abertura, a ferramenta reporta falha (não finge sucesso). `switch_app` retoma pelo ícone de lançador, não pela lista de recentes.
