// Servidor intermediário do JARVIS. Sem dependências externas (Node >= 18).
// Variáveis de ambiente:
//   OPENAI_API_KEY      (obrigatória) chave da OpenAI — fica SOMENTE aqui
//   JARVIS_APP_TOKENS   (obrigatória) tokens aceitos do app, separados por vírgula
//   OPENAI_MODEL        modelo de chat com function calling (padrão: gpt-4.1)
//   OPENAI_BASE_URL     padrão https://api.openai.com/v1
//   PORT                padrão 8787
// IMPORTANTE: publique atrás de HTTPS (o app só aceita https://).
import http from 'node:http';
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

export const ALLOWED_TOOLS = new Set([
  'get_current_app', 'inspect_screen', 'find_element', 'tap_element', 'type_text', 'scroll_screen',
  'press_back', 'press_home', 'open_app', 'switch_app', 'wait_for_screen_change', 'read_accessible_text',
  'capture_screen', 'tap_point', 'set_plan', 'report_progress', 'finish_task',
]);

function readGeminiKey() {
  // Prefer the host's secret/environment variable. For a private self-hosted
  // installation, a visible text file beside server.js is also supported.
  if (process.env.GEMINI_API_KEY?.trim()) return process.env.GEMINI_API_KEY.trim();
  try {
    const value = readFileSync(new URL('./GEMINI_API_KEY.txt', import.meta.url), 'utf8').trim();
    if (value && !value.startsWith('COLE_SUA_CHAVE') && !value.startsWith('COLE_A_CHAVE')) return value;
  } catch {}
  return undefined;
}

const MAX_BODY = 4 * 1024 * 1024;
const MAX_MESSAGES = 120;

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

export function createServer(opts = {}) {
  const cfg = {
    apiKey: opts.apiKey ?? readGeminiKey(),
    tokens: opts.tokens ?? (process.env.JARVIS_APP_TOKENS || '').split(',').map((s) => s.trim()).filter(Boolean),
    model: opts.model ?? process.env.GEMINI_MODEL ?? 'gemini-3.8-flash',
    baseUrl: (opts.baseUrl ?? process.env.GEMINI_BASE_URL ?? 'https://generativelanguage.googleapis.com/v1beta/openai').replace(/\/$/, ''),
    ratePerMin: opts.ratePerMin ?? Number(process.env.JARVIS_RATE_PER_MIN || 5),
    dailyLimit: opts.dailyLimit ?? Number(process.env.JARVIS_DAILY_LIMIT || 30),
  };
  const hits = new Map(); // token -> [timestamps] (minute)
  const dailyHits = new Map(); // token -> [timestamps] (24h)

  function authorized(req) {
    const h = req.headers['authorization'] || '';
    const m = /^Bearer (.+)$/.exec(h);
    if (!m) return null;
    for (const t of cfg.tokens) if (safeEqual(m[1], t)) return t;
    return null;
  }

  function limited(token) {
    const now = Date.now();
    const minute = (hits.get(token) || []).filter((t) => now - t < 60_000);
    minute.push(now);
    hits.set(token, minute);

    const day = (dailyHits.get(token) || []).filter((t) => now - t < 24 * 60 * 60 * 1000);
    if (minute.length > cfg.ratePerMin || day.length >= cfg.dailyLimit) {
      dailyHits.set(token, day);
      return true;
    }
    day.push(now);
    dailyHits.set(token, day);
    return false;
  }

  function send(res, code, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
    res.end(body);
  }

  function readBody(req) {
    return new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > MAX_BODY) { reject(Object.assign(new Error('too large'), { code: 413 })); req.destroy(); return; }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  return http.createServer(async (req, res) => {
    try {
      const token = authorized(req);
      if (!token) return send(res, 401, { error: 'unauthorized' });
      if (req.method === 'GET' && req.url === '/health') return send(res, 200, { ok: true });
      if (req.method !== 'POST' || req.url !== '/v1/agent/step') return send(res, 404, { error: 'not found' });
      if (limited(token)) return send(res, 429, { error: 'rate limited' });
      if (!cfg.apiKey) return send(res, 500, { error: 'server not configured' });

      let body;
      try { body = JSON.parse(await readBody(req)); } catch (e) {
        return send(res, e.code === 413 ? 413 : 400, { error: 'invalid body' });
      }
      const { messages, tools } = body || {};
      if (!Array.isArray(messages) || messages.length === 0 || messages.length > MAX_MESSAGES) return send(res, 400, { error: 'invalid messages' });
      if (!Array.isArray(tools) || tools.length > 40) return send(res, 400, { error: 'invalid tools' });
      for (const t of tools) {
        const name = t?.function?.name;
        if (t?.type !== 'function' || !ALLOWED_TOOLS.has(name)) return send(res, 400, { error: 'tool not allowed' });
      }
      for (const m of messages) {
        if (!['system', 'user', 'assistant', 'tool'].includes(m?.role)) return send(res, 400, { error: 'invalid role' });
      }

      const upstream = await fetch(`${cfg.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.apiKey}` },
        body: JSON.stringify({ model: cfg.model, messages, tools, tool_choice: 'auto' }),
        signal: AbortSignal.timeout(60_000),
      });
      if (!upstream.ok) {
        console.error('upstream error', upstream.status); // não vaza detalhes ao app
        return send(res, 502, { error: 'upstream error' });
      }
      const data = await upstream.json();
      const message = data?.choices?.[0]?.message;
      if (!message) return send(res, 502, { error: 'empty upstream response' });
      return send(res, 200, { message, usage: data.usage ?? null });
    } catch (e) {
      console.error('server error', e?.name);
      return send(res, 500, { error: 'internal error' });
    }
  });
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  if (!process.env.GEMINI_API_KEY || !process.env.JARVIS_APP_TOKENS) {
    console.error('Defina GEMINI_API_KEY e JARVIS_APP_TOKENS.');
    process.exit(1);
  }
  const port = Number(process.env.PORT || 8787);
  createServer().listen(port, () => console.log(`JARVIS Gemini proxy em :${port}`));
}
