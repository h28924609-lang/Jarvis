import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createServer } from './server.js';

function listen(srv) { return new Promise((r) => srv.listen(0, '127.0.0.1', () => r(srv.address().port))); }
const tool = (name) => ({ type: 'function', function: { name, description: 'x', parameters: { type: 'object', properties: {} } } });

async function setup(extra = {}) {
  let lastUpstream = null;
  const fake = http.createServer((req, res) => {
    let b = ''; req.on('data', (c) => (b += c));
    req.on('end', () => {
      lastUpstream = { auth: req.headers.authorization, body: JSON.parse(b) };
      if (extra.upstreamFail) { res.writeHead(500); return res.end('{"secret":"boom"}'); }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'ok' } }], usage: { total_tokens: 1 } }));
    });
  });
  const fp = await listen(fake);
  const app = createServer({ apiKey: 'sk-test', tokens: ['tok'], baseUrl: `http://127.0.0.1:${fp}/v1`, model: 'm', ...extra.opts });
  const ap = await listen(app);
  const call = (path, { method = 'POST', token = 'tok', body } = {}) =>
    fetch(`http://127.0.0.1:${ap}${path}`, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { call, close: () => { app.close(); fake.close(); }, last: () => lastUpstream };
}

const good = { messages: [{ role: 'user', content: 'oi' }], tools: [tool('inspect_screen')] };

test('rejeita sem token e com token errado', async () => {
  const s = await setup();
  assert.equal((await s.call('/health', { method: 'GET', token: null })).status, 401);
  assert.equal((await s.call('/health', { method: 'GET', token: 'x' })).status, 401);
  assert.equal((await s.call('/health', { method: 'GET' })).status, 200);
  s.close();
});

test('encaminha ao provedor Gemini compatível com a chave do servidor e devolve a mensagem', async () => {
  const s = await setup();
  const r = await s.call('/v1/agent/step', { body: good });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).message.content, 'ok');
  assert.equal(s.last().auth, 'Bearer sk-test');
  assert.equal(s.last().body.tool_choice, 'auto');
  s.close();
});

test('rejeita ferramenta fora da lista permitida', async () => {
  const s = await setup();
  const r = await s.call('/v1/agent/step', { body: { ...good, tools: [tool('run_shell')] } });
  assert.equal(r.status, 400);
  s.close();
});

test('valida mensagens e papéis', async () => {
  const s = await setup();
  assert.equal((await s.call('/v1/agent/step', { body: { messages: [], tools: [] } })).status, 400);
  assert.equal((await s.call('/v1/agent/step', { body: { ...good, messages: [{ role: 'root', content: 'x' }] } })).status, 400);
  s.close();
});

test('não vaza detalhes de erro do upstream', async () => {
  const s = await setup({ upstreamFail: true });
  const r = await s.call('/v1/agent/step', { body: good });
  assert.equal(r.status, 502);
  assert.ok(!JSON.stringify(await r.json()).includes('boom'));
  s.close();
});

test('limita requisições por minuto', async () => {
  const s = await setup({ opts: { ratePerMin: 2 } });
  assert.equal((await s.call('/v1/agent/step', { body: good })).status, 200);
  assert.equal((await s.call('/v1/agent/step', { body: good })).status, 200);
  assert.equal((await s.call('/v1/agent/step', { body: good })).status, 429);
  s.close();
});

test('limita também o total diário por token', async () => {
  const s = await setup({ opts: { dailyLimit: 2, ratePerMin: 20 } });
  assert.equal((await s.call('/v1/agent/step', { body: good })).status, 200);
  assert.equal((await s.call('/v1/agent/step', { body: good })).status, 200);
  assert.equal((await s.call('/v1/agent/step', { body: good })).status, 429);
  s.close();
});
