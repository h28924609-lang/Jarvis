## Colocar a chave pelo celular (arquivo visível)

Na mesma pasta de `server.js`, abra o arquivo **`GEMINI_API_KEY.txt`** e substitua o texto `COLE_SUA_CHAVE_DO_GEMINI_AQUI` pela sua chave, salve e mantenha esse arquivo no servidor. O servidor lê esse arquivo automaticamente se `GEMINI_API_KEY` não estiver cadastrada nas variáveis de ambiente. **Não coloque esse arquivo no APK nem compartilhe o ZIP depois de inserir sua chave.** Para hospedagem, o método mais seguro continua sendo cadastrar `GEMINI_API_KEY` em Environment Variables/Secrets do painel.

# Servidor intermediário do JARVIS — Gemini

Este servidor mantém a chave Gemini fora do APK e conserva a interface que o app já usa (`/v1/agent/step`). O servidor encaminha `messages` e `tools` ao endpoint compatível com OpenAI do Gemini.

## Configuração

Requisitos: Node.js 18 ou superior.

Configure estas variáveis no ambiente do servidor (não no APK):

```bash
GEMINI_API_KEY=sua_chave_do_google_ai_studio
GEMINI_MODEL=gemini-3.8-flash
GEMINI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai
JARVIS_APP_TOKENS=gere_um_token_longo_e_aleatorio
JARVIS_RATE_PER_MIN=5
JARVIS_DAILY_LIMIT=30
PORT=8787
```

No terminal Linux/macOS, gere o token do app com:

```bash
openssl rand -hex 24
```

O token gerado vai no campo **Token do app** dentro das configurações do Jarvis. A chave `GEMINI_API_KEY` fica somente como variável de ambiente no servidor.

## Limite de uso e prevenção de cobrança

- O proxy limita cada token a 5 chamadas por minuto e 30 chamadas em uma janela móvel de 24 horas por padrão.
- Você pode reduzir esses limites com `JARVIS_RATE_PER_MIN` e `JARVIS_DAILY_LIMIT`.
- O limite do proxy não substitui os limites gratuitos do Google.
- Para não gastar dinheiro, **não vincule uma conta de faturamento ao projeto Google** e não habilite faturamento. Sem faturamento, quando a cota gratuita acabar, a API deve recusar novas chamadas em vez de passar para cobrança.
- A disponibilidade e a cota gratuita dependem do modelo, região, projeto e regras vigentes do Google. Confira o painel de uso do AI Studio.

## Executar

```bash
export GEMINI_API_KEY="sua-chave"
export JARVIS_APP_TOKENS="$(openssl rand -hex 24)"
export GEMINI_MODEL="gemini-3.8-flash"
node server.js
```

Publique atrás de HTTPS. O app exige URL HTTPS e envia o token do app no cabeçalho Authorization.

## Testes

```bash
npm test
```

Os testes usam um servidor falso local e não chamam o Google nem consomem cota.
